# Athlete Club

App Android nativa (Kotlin + Jetpack Compose) para elegir un deporte (Correr, Sendero, Bicicleta o Caminata), salir a practicarlo
y guardar el recorrido en un historial privado; preparar entrenamientos y quedar con un club. **No es una red social** y
**no usa inteligencia artificial**: las propuestas salen de reglas y plantillas documentadas.

Esta versión (2.0.0) actualiza el proyecto anterior conservando `applicationId` (`app.fuckrun`), firma y datos:
la base de datos migra de v1 a v2 y las carreras existentes quedan como «Correr». Ver `docs/ENTREGA.md`.

## Compilar e instalar

Requisitos: Android Studio (Ladybug o posterior) con Android SDK 35 y JDK 17.

```bash
cp local.properties.example local.properties   # sdk.dir y, opcionalmente, mapas y Firebase
./gradlew assembleDebug                        # APK en app/build/outputs/apk/debug/
./gradlew installDebug                         # instala encima de la versión anterior (misma firma)
./gradlew test                                 # pruebas de métricas, deportes y reglas
```

**Firma**: para actualizar sin perder datos hay que firmar con la MISMA clave que la versión instalada (en depuración, el
mismo `debug.keystore`; en publicación, la clave de subida de Play). Sin claves de Firebase todo funciona en local
(registro, historial, estadísticas, rutinas); la cuenta y Club muestran «no configurado». Cuenta y reglas: `docs/CUENTA.md`.

## Estructura

```
app/src/main/java/app/fuckrun/
  domain/            Lógica pura y probada: métricas GPS, nivel, reglas de recomendación, progreso
  data/              Almacenamiento PERSONAL (Room + DataStore), municipios, catálogo de rutas, exportación
  data/shared/       Datos COMPARTIDOS (Firebase Auth + Firestore), separados del almacenamiento personal
  tracking/          Servicio en primer plano de ubicación (pantalla apagada, huecos, batería, recuperación)
  reminders/         Recordatorios de rutina y avisos de cambios en sesiones conjuntas
  ui/                Tema, componentes (barra flotante, hojas con desenfoque, difuminado superior), pantallas
firebase/firestore.rules   Reglas de seguridad del servicio compartido
tools/import_ine.py        Carga el listado completo de municipios del INE
docs/                      Decisiones, métricas, plantillas, rutas, servicios y exportación
```

## Decisiones importantes

- **Ubicación**: solo `ACCESS_FINE_LOCATION`/`COARSE` mientras se usa la app. El seguimiento con pantalla apagada se hace con un *foreground service* de tipo `location` que el usuario inicia, con notificación visible. **No** se pide ubicación en segundo plano permanente. Al terminar o descartar, la captura se detiene.
- **Resiliencia**: cada punto y evento se guarda al momento. Si el sistema cierra la app o se reinicia el dispositivo, al abrirla se ofrece continuar, terminar o descartar, indicando el tramo perdido. Los huecos nunca se dibujan como recorrido (línea discontinua) ni suman distancia.
- **Métricas**: filtros documentados en `docs/METRICAS.md`. Si no hay datos suficientes se muestra «–», nunca un valor inventado. Una parada real muestra 0.
- **Recomendaciones**: reglas explícitas y plantillas con procedencia (`docs/PLANTILLAS.md`). Cada propuesta indica qué respuestas usa. La carga nunca sube sola.
- **Rutas**: el catálogo se publica **vacío** a propósito. Solo se muestran recorridos verificados (`docs/RUTAS.md`). Sin catálogo, la app ofrece sesiones por tiempo o distancia.
- **Privacidad**: actividades privadas y locales. Nada de feed, seguidores, «me gusta», comentarios ni rankings. Apuntarse a una sesión no comparte ruta, ritmo, estadísticas ni posición.
- **Diseño**: temas Claro, Oscuro y Automático (Perfil → Apariencia); Inter Regular (400) en todos los textos con −0,08 em; cifras
  tabulares; cápsula inferior flotante y menús de vidrio (Haze → `RenderEffect` en Android 12+, película translúcida en anteriores);
  menús anclados al control pulsado; respuesta táctil común (`Modifier.liquid`). Marca: `docs/MARCA.md`.
- **Deportes**: el deporte es un dato independiente del origen (libre, rutina, ruta o encuentro). Umbrales por deporte en `docs/METRICAS.md`.

## Pendiente antes de publicar

1. Compilar y probar en dispositivos reales (este proyecto se ha generado sin Android SDK; la lógica de dominio sí está compilada y probada).
2. Configurar proveedor de mapas con licencia comercial y proyecto Firebase propio.
3. Revisión profesional de las plantillas de entrenamiento.
4. Cargar el listado completo de municipios del INE y los primeros recorridos verificados.
5. Declaración del permiso de servicio en primer plano de ubicación en Google Play Console (vídeo y justificación).
