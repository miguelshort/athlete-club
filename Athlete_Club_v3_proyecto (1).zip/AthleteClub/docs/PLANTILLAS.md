# Plantillas y reglas de recomendación

Implementación: `domain/Onboarding.kt` (nivel) y `domain/Recommendations.kt` (reglas). Sin IA.

> **Estado: pendiente de revisión profesional.** Son plantillas orientativas y conservadoras. No son un programa clínico, no garantizan resultados y deben revisarse por un profesional cualificado (entrenador titulado o profesional sanitario del deporte) antes de publicar.

## Procedencia
- **Alternancia caminar/correr** para quien empieza: enfoque usado en programas públicos de iniciación como *Couch to 5K* del NHS (Reino Unido). Se toma el enfoque general (bloques cortos de carrera suave + caminar, tres días por semana con descanso entre medias), no su calendario.
- **Volumen semanal de referencia**: Directrices de la OMS sobre actividad física y hábitos sedentarios (2020): 150–300 min/semana de actividad aeróbica moderada para adultos.
- **Intensidad**: «prueba del habla» (poder conversar = suave; frases cortas = moderada), descrita por organismos de salud pública como los CDC.

## Nivel orientativo (solo respuestas de experiencia y capacidad; nunca la ciudad)
| Nivel | Regla |
|---|---|
| Inicio | No corre y su tiempo seguido cómodo es < 15 min o desconocido; o puede correr seguido menos de 5 min. |
| Continuidad | Corre de forma regular, ≥ 3 días/semana y ≥ 30 min seguidos cómodos. |
| Base | El resto. |
El usuario puede cambiarlo; se muestra el motivo.

## Reglas de sesión
- Se reservan 10 min para calentamiento (5 min caminando a paso vivo) y vuelta a la calma (5 min caminando suave).
- **Inicio**: N × (1–2 min corriendo suave + 2 min caminando), N entre 3 y 8 según el tiempo disponible.
- **Base**: rodaje suave con la duración que ya tolera (sin superarla), limitado por el tiempo disponible.
- **Continuidad**: rodaje de duración habitual; una sesión semanal opcional con 4–6 cambios cortos de 20 s.
- **Días**: hasta 3 (Inicio), 4 (Base) o 5 (Continuidad), elegidos entre los disponibles maximizando la separación.
- **Limitación indicada**: intensidad «muy suave», −25 % de duración, sin cambios de ritmo y opción de sustituir por descanso o caminata.
- **Sin progresión automática**: completar sesiones nunca sube la carga.
- Cada propuesta permite **reducir** (−30 %), **cambiar** (caminata o descanso) y **posponer**.
