# Entrega v3 — Athlete Club

## Qué cambia
- **Bienvenida a pantalla completa** en cada apertura desde el icono: «{saludo}, {nombre}. {pregunta}» con el banco de 80 preguntas (anexo).
  Rotación sin repetir por perfil y franja (mañana 6–11, mediodía 12–14, tarde 15–20, noche 21–5); se reinicia al agotar el grupo
  sin repetir la última. La frase se fija al abrir y no cambia al desplegar deportes ni al rotar.
  - «Elegir deporte» se expande en las cuatro filas; al tocar una se abre la preparación con ese deporte.
  - «Solo quiero entrar en la aplicación» → Inicio.
  - «Volver a mi actividad» si hay un registro en curso.
  - Notificación de la actividad, invitaciones y volver al rato (<30 min) **no** muestran la bienvenida.
- **Primera instalación**: bienvenida → tutorial (se puede omitir) → presentación de cuenta (si Firebase está configurado) → destino elegido.
- **Inicio** sin saludo; retrato del avatar arriba a la derecha que abre el **Vestidor**. Acceso directo a Rutinas.
- **Navegación por secciones** (`goSection`): la pestaña activa se calcula a partir del destino real (los detalles cuentan como su sección);
  tocar Inicio vuelve a su raíz en un toque; cada sección conserva su pila.
- **Liquid Glass**: pulsación asimétrica (el borde cede 2–3 dp, cuerpo +4 % ancho / −2 % alto, brillo bajo el dedo, tinte al mantener,
  muelle ~180 ms, acción al soltar), menús que nacen del control (220 ms / cierre 180 ms), lente en la barra, interruptor de cristal, desenfoque 32 dp.
- **Rutinas semanal**: calendario de 7 días con flechas, detalle del día («Sin rutina para este día», «Añadir sesión», «Descanso»).
- **Rutas por ciudad** desde OpenStreetMap en vivo (ver RUTAS.md): «Rutas en {municipio}», hasta 5 rutas distintas por deporte,
  ampliación a alrededores con municipio y distancia, filtros, caché sin conexión, «Guardar» y «Usar esta ruta».
- **Avatar 2,5D** en Compose, Vestidor (aspecto, ropa, accesorios) y **Tienda** con puntos:
  10 por actividad medida ≥5 min, +5 por cada récord mejorado (distancia, duración, mejor 1 km). Accesorios por hito:
  gafas de bici, cinta de running, cantimplora de sendero, riñonera de caminata. Libro de puntos idempotente y sincronizado.
- **Tutorial** actualizado: Bienvenida e Inicio, Rutas, Rutinas y nueva diapositiva «Avatar y Tienda».

## Verificado
- Pruebas de dominio: 27/27 (saludos 80, franjas, rotación, primera instalación, récords y puntos, mejor 1 km, selección y duplicados de rutas).
- La interfaz Android no se ha podido compilar en este entorno (sin SDK): la compilación la valida el workflow de GitHub,
  que imprime los errores en el resumen.

## Pendiente de probar en dispositivo
- Apertura desde icono / notificación / segundo plano largo y corto.
- Base de datos v2 → v3 (migración `MIGRATION_2_3`) con datos reales.
- Consultas Overpass en municipios pequeños y sin conexión.
- Sensación de las animaciones de cristal en gama media y con «Quitar animaciones».
