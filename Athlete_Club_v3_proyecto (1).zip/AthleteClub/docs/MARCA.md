# Marca: «Athlete Club»

- Nombre visible exacto: **Athlete Club** (lanzador, bienvenida, interfaz, notificaciones, invitaciones y exportaciones).
- Se conservan el `applicationId` (`app.fuckrun`) y el `namespace` interno para que la actualización se instale sobre la
  versión anterior con la misma firma y sin perder datos. Ninguno de los dos es visible para la persona usuaria.

## ¿Se puede aislar la silueta del logotipo antiguo?

No de forma limpia. En `docs/logo_original.jpg` la figura del atleta está apoyada en la «f» de «fkrun»: la espalda y la
cadera forman un único trazo con el asta de la letra (comprobado por componentes conexos: la silueta y «fkr» son la misma
mancha). Separarla obligaría a inventar el contorno de la espalda, así que, como indica el encargo:

- En la interfaz se usa el nombre «Athlete Club» en Inter Regular (`BrandName` en `ui/components/Components.kt`).
- En el lanzador se usa un **pictograma deportivo provisional** (figura corriendo, `res/drawable/ic_launcher_foreground.xml`),
  con capa monocroma para iconos temáticos de Android 13+.
- Se han eliminado del APK el logotipo antiguo y los iconos que llevaban el nombre anterior.

Si se facilita un logotipo nuevo, sustituir `ic_launcher_foreground.xml`/`ic_launcher_monochrome.xml` y, si procede,
`BrandName` por la imagen original sin modificarla.
