# Servicios externos: claves, costes, límites y atribuciones

Datos consultados en noviembre de 2026. **Compruébalos antes de publicar**: los proveedores cambian precios y condiciones.

## 1. Mapas (teselas)

La app usa **osmdroid** (Apache 2.0) con una fuente de teselas XYZ configurable en `local.properties` (`MAP_TILE_URL`, `MAP_ATTRIBUTION`). La atribución se muestra siempre sobre el mapa.

| Opción | Uso | Notas |
|---|---|---|
| Servidor estándar de OpenStreetMap (por defecto si `MAP_TILE_URL` está vacío) | **Solo desarrollo** | La política de la OSMF prohíbe el uso intensivo (p. ej., distribuir una app de uso intenso) sin permiso previo y puede bloquear sin aviso. Requiere atribución «© OpenStreetMap contributors». |
| MapTiler Cloud | Producción | El plan gratuito es solo para uso no comercial o desarrollo y se suspende al alcanzar el límite mensual (del orden de 5.000 sesiones y 100.000 peticiones). Plan Flex de pago desde unos 30 $/mes. Clave en la URL (`?key=`). Atribución: «© MapTiler © OpenStreetMap contributors». |
| Stadia Maps | Producción | Plan gratuito no comercial; planes de pago desde unos 20–80 $/mes según volumen. |

**Recomendación**: MapTiler o Stadia con plan comercial, estilo oscuro raster XYZ de 256 px. Protege la clave restringiéndola por paquete Android en el panel del proveedor.

Los datos de OpenStreetMap tienen licencia **ODbL**: cualquier ruta derivada de OSM debe citar la fuente.

## 2. Servicio compartido (sesiones conjuntas)

**Firebase Authentication (anónima) + Cloud Firestore**. Se inicializa manualmente con `FIREBASE_API_KEY`, `FIREBASE_APP_ID` y `FIREBASE_PROJECT_ID`; si faltan, Club muestra «servicio no configurado» (no se simula nada).

Pasos:
1. Crea un proyecto en Firebase y añade una app Android con id `app.fuckrun`.
2. Activa *Authentication → Anonymous*.
3. Crea la base de datos Firestore (región UE, p. ej. `europe-southwest1` Madrid) y despliega `firebase/firestore.rules`.
4. Copia API key, App ID y Project ID a `local.properties`.
5. Recomendado: activa **App Check** (Play Integrity) para impedir el uso de la API key desde fuera de la app.

Costes: el plan gratuito Spark incluye 50.000 lecturas, 20.000 escrituras y 20.000 borrados al día y 1 GiB almacenado; al superarlo se corta el servicio ese periodo. Con Blaze (pago por uso) se mantiene la cuota gratuita y se paga el exceso. Uso estimado: crear una sesión ≈ 4 escrituras; confirmar asistencia ≈ 3 escrituras y 2 lecturas; cada cambio vigilado ≈ 1 lectura por asistente conectado.

### Notificaciones con la app cerrada
La versión actual avisa de cambios mientras la app está abierta y conectada (escucha en tiempo real). Para avisar con la app cerrada hace falta **Firebase Cloud Messaging** + una **Cloud Function** que envíe el push al modificar `sessions/{id}` (requiere plan Blaze). No está implementado para no aparentar un envío que no existe.

## 3. Municipios
`app/src/main/assets/municipios.csv` incluye solo capitales y municipios grandes como subconjunto inicial. El listado completo procede de la **Relación de municipios y sus códigos por provincias del INE** (datos abiertos; citar la fuente). Carga: `python3 tools/import_ine.py diccionarioXX.csv > app/src/main/assets/municipios.csv`.

## 4. Tipografía
Inter (SIL Open Font License 1.1), incluida en `res/font`. Licencia en `docs/INTER_LICENSE.txt`.
