package app.fuckrun.domain

import app.fuckrun.domain.metrics.RunMetrics
import app.fuckrun.domain.metrics.RunMetrics.Sample
import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random

class V3Test {
    @Test fun bankHas80Questions() {
        assertEquals(80, GreetingBank.all.size)
        DayPart.entries.forEach { p ->
            assertEquals(12, GreetingBank.all.count { it.part == p && it.sport == null })
            Sport.entries.forEach { s -> assertEquals(2, GreetingBank.all.count { it.part == p && it.sport == s }) }
        }
        assertEquals(80, GreetingBank.all.map { it.id }.toSet().size)
    }

    @Test fun dayPartBoundaries() {
        assertEquals(DayPart.NIGHT, DayPart.of(5))      // 05:59
        assertEquals(DayPart.MORNING, DayPart.of(6))    // 06:00
        assertEquals(DayPart.MIDDAY, DayPart.of(12))    // 12:00
        assertEquals(DayPart.AFTERNOON, DayPart.of(15)) // 15:00
        assertEquals(DayPart.NIGHT, DayPart.of(21))     // 21:00
    }

    @Test fun rotationNoRepeatsUntilExhausted() {
        val r = Random(7)
        var st: GreetingCycle? = null
        val seen = mutableListOf<String>()
        repeat(14) { val (q, s) = GreetingRotation.next(DayPart.NIGHT, Sport.RUN, false, st, r); seen += q.id; st = s }
        assertEquals(14, seen.toSet().size)  // 12 generales + 2 de correr, sin repetir
        repeat(200) {
            val last = st!!.last
            val (q, s) = GreetingRotation.next(DayPart.NIGHT, Sport.RUN, false, st, r)
            if (st!!.shown.size == 14) assertTrue("un ciclo nuevo no empieza por la última", q.id != last)
            st = s
        }
    }

    @Test fun firstInstallUsesGeneral() {
        val (q, _) = GreetingRotation.next(DayPart.MORNING, Sport.BIKE, true, null)
        assertNull(q.sport)
        assertEquals("Buenas noches. ¿Cómo te apetece cerrar el día?", GreetingRotation.compose(DayPart.NIGHT, null, GreetingBank.byId("n.g1")!!))
        assertEquals("Buenas noches, Miguel. ¿Preparándote para tu carrera nocturna?", GreetingRotation.compose(DayPart.NIGHT, "Miguel", GreetingBank.byId("n.run1")!!))
    }

    private fun f(id: String, s: Sport, t: Long, ms: Long, d: Double?, k: Long?) = RunFacts(id, s, t, true, ms, d, k)

    @Test fun recordsAndPointsAreStableAndPerSport() {
        val a = f("a", Sport.BIKE, 1, 30 * 60_000, 10_000.0, 120_000)
        val e1 = Rewards.evaluate(a, emptyList())
        assertEquals(10, e1.points)                       // referencia: sin extra
        assertTrue(e1.changes.all { it.isReference })
        val b = f("b", Sport.BIKE, 2, 40 * 60_000, 12_000.0, 100_000)
        val e2 = Rewards.evaluate(b, listOf(a))
        assertEquals(10 + 3 * 5, e2.points)
        assertEquals(listOf("glasses_bike"), e2.unlocks.map { it.id })
        assertEquals(setOf("act:b", "rec:b:DISTANCE", "rec:b:DURATION", "rec:b:SPEED_1K"), e2.entries.map { it.id }.toSet())
        // Otro deporte no compara con bici; una sesión corta no puntúa
        assertEquals(10, Rewards.evaluate(f("c", Sport.RUN, 3, 30 * 60_000, 20_000.0, 200_000), listOf(a, b)).points)
        assertEquals(0, Rewards.evaluate(f("d", Sport.RUN, 4, 4 * 60_000, 1_000.0, null), emptyList()).points)
        assertEquals(e2.entries, Rewards.evaluate(b, listOf(a)).entries)   // determinista
    }

    @Test fun paceUsesLowerIsBetter() {
        val a = f("a", Sport.RUN, 1, 30 * 60_000, 5000.0, 330_000)
        val b = f("b", Sport.RUN, 2, 20 * 60_000, 4000.0, 300_000)
        val e = Rewards.evaluate(b, listOf(a))
        assertEquals(listOf(RecordCat.PACE_1K), e.changes.filter { !it.isReference }.map { it.cat })
        assertEquals(listOf("headband_run"), e.unlocks.map { it.id })
    }

    @Test fun best1kFromPoints() {
        val deg = 1.0 / 111_195.0
        val pts = (0..400).map { i -> Sample(0, i * 1000L, i * 1000L, 40.0 + i * 3.0 * deg, -3.0, 5f) }
        val k = RunMetrics.best1kMs(listOf(pts))!!
        assertEquals(333_333.0, k.toDouble(), 6_000.0)
        val bad = pts.map { it.copy(accuracyM = 20f) }
        assertNull(RunMetrics.best1kMs(listOf(bad)))
    }

    private fun c(id: String, name: String, d: Double, lat: Double, lon: Double = -6.0) = RouteCandidate(id, name, d, null, null, lat, lon, lat + 0.001, lon)

    @Test fun routeSelectionDedupesAndIsStable() {
        val list = listOf(
            c("1", "Ruta del río", 5000.0, 37.0), c("2", "Ruta del Río (variante)", 5200.0, 37.3),
            c("3", "Parque A", 3000.0, 37.1), c("4", "Parque B", 3050.0, 37.1001),   // misma salida y llegada: variante
            c("5", "Larga", 15000.0, 37.2), c("6", "Corta", 1200.0, 37.4), c("7", "Media", 8000.0, 37.5), c("8", "Otra", 10000.0, 37.6),
        )
        val p1 = RouteSelect.pick(list)
        assertEquals(5, p1.size)
        assertEquals(5, p1.map { it.id }.toSet().size)
        assertFalse(p1.any { it.id == "2" } && p1.any { it.id == "1" })
        assertFalse(p1.any { it.id == "4" } && p1.any { it.id == "3" })
        assertEquals(p1, RouteSelect.pick(list.reversed()))
        assertEquals(2, RouteSelect.pick(list.take(4)).size)  // dos pares de variantes → 2 recorridos
    }
}
