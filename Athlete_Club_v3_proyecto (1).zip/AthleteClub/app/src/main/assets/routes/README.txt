Catálogo de recorridos verificados. Se publica VACÍO a propósito: la app no inventa rutas.
Cada recorrido es un archivo .json con el esquema de docs/RUTAS.md y solo se añade tras
verificación (fuente con licencia compatible + revisión sobre el terreno o por fuente oficial).
