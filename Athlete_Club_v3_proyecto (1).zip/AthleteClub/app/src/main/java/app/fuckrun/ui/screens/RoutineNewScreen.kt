package app.fuckrun.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.data.AppSettings
import app.fuckrun.domain.*
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun RoutineNewScreen(nav: NavController) {
    val g = FuckrunApp.graph
    val scope = rememberCoroutineScope()
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    var fromTemplate by remember { mutableStateOf(true) }
    var weeks by remember { mutableIntStateOf(4) }
    var start by remember { mutableStateOf(LocalDate.now()) }
    var name by remember { mutableStateOf("Mi rutina") }
    var kind by remember { mutableStateOf("WEEKLY") }
    var sport by remember(settings.lastFreeSport) { mutableStateOf(settings.lastFreeSport) }
    val answers = settings.answersFor(sport)
    val suggestion = remember(answers, sport) { RecommendationEngine.weekly(answers, sport) }
    val level = LevelClassifier.classify(answers, sport).level
    val tpl = Templates.forSport(sport, level)

    ScreenScaffold("Nueva rutina") {
        item { SportSelector(sport) { sport = it } }
        item { ChoiceChips(listOf(true, false), { if (it) "Desde plantilla" else "Desde cero" }, { it == fromTemplate }) { fromTemplate = it } }
        item {
            Text("Duración", style = T.BodyStrong, modifier = Modifier.padding(start = 4.dp))
            Spacer(Modifier.height(8.dp))
            ChoiceChips(listOf(1, 2, 4, 6, 8), { if (it == 1) "1 semana" else if (it == 4) "1 mes (4 sem.)" else "$it semanas" }, { it == weeks }) { weeks = it; kind = if (it == 1) "WEEKLY" else if (it == 4) "MONTHLY" else "CUSTOM" }
            Spacer(Modifier.height(8.dp))
            ChoiceChips(listOf(LocalDate.now(), LocalDate.now().plusDays(1), LocalDate.now().with(java.time.temporal.TemporalAdjusters.next(java.time.DayOfWeek.MONDAY))),
                { if (it == LocalDate.now()) "Empieza hoy" else if (it == LocalDate.now().plusDays(1)) "Mañana" else "Próximo lunes" }, { it == start }) { start = it }
        }
        if (fromTemplate) {
            item {
                FCard {
                    Text("Plantilla ${tpl.name} · ${sport.label} · nivel ${level.label}", style = T.Label)
                    Text("Semana tipo", style = T.Section)
                    Spacer(Modifier.height(8.dp))
                    suggestion.days.forEach { (d, p) -> Detail(Fmt.dayName(d), "${p.title}: ${p.structure} (${p.intensity.label.lowercase()})") }
                    Text("Los demás días quedan como descanso.", style = T.Label)
                    Spacer(Modifier.height(8.dp))
                    Detail("Regla aplicada", suggestion.rule)
                    Detail("Basada en", suggestion.usedAnswers.joinToString(" · "))
                    Detail("Procedencia", tpl.source)
                    Spacer(Modifier.height(6.dp))
                    Text("La carga no aumenta automáticamente semana a semana. Revisa y edita cada sesión cuando quieras.", style = T.Label)
                }
            }
        } else {
            item { Field(name, "Nombre de la rutina", singleLine = true) { name = it } }
            item { Text("Después podrás añadir sesiones y descansos día a día.", style = T.Label, modifier = Modifier.padding(start = 4.dp)) }
        }
        item {
            PillButton("Crear rutina", color = C.Green, icon = Icons.Rounded.Check, modifier = Modifier.fillMaxWidth(), enabled = fromTemplate || name.isNotBlank()) {
                scope.launch {
                    if (fromTemplate) g.routines.createFromTemplate(answers, weeks, start, sport)
                    else g.routines.createManual(name.trim(), kind, start, start.plusWeeks(weeks.toLong()).minusDays(1))
                    nav.popBackStack()
                }
            }
        }
    }
}
