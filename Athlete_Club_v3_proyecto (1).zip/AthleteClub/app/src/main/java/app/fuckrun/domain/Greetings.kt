package app.fuckrun.domain

import kotlinx.serialization.Serializable
import kotlin.random.Random

/** Franjas horarias de la bienvenida (hora local del móvil). */
enum class DayPart(val salute: String) {
    MORNING("Buenos días"),      // 06:00–11:59
    MIDDAY("Buenas"),            // 12:00–14:59
    AFTERNOON("Buenas tardes"),  // 15:00–20:59
    NIGHT("Buenas noches");      // 21:00–05:59

    companion object {
        fun of(hour: Int): DayPart = when (hour) {
            in 6..11 -> MORNING
            in 12..14 -> MIDDAY
            in 15..20 -> AFTERNOON
            else -> NIGHT
        }
    }
}

/** Pregunta del banco. Las etiquetas de franja y deporte son internas: en pantalla solo se ve el texto. */
data class Question(val id: String, val part: DayPart, val sport: Sport?, val text: String)

/** Banco local de 80 preguntas (12 generales y 2 por deporte en cada franja). Disponible sin conexión. */
object GreetingBank {
    private fun block(p: DayPart, key: String, general: List<String>, run: List<String>, hike: List<String>, bike: List<String>, walk: List<String>) =
        general.mapIndexed { i, t -> Question("$key.g${i + 1}", p, null, t) } +
            run.mapIndexed { i, t -> Question("$key.run${i + 1}", p, Sport.RUN, t) } +
            hike.mapIndexed { i, t -> Question("$key.hike${i + 1}", p, Sport.HIKE, t) } +
            bike.mapIndexed { i, t -> Question("$key.bike${i + 1}", p, Sport.BIKE, t) } +
            walk.mapIndexed { i, t -> Question("$key.walk${i + 1}", p, Sport.WALK, t) }

    val all: List<Question> = block(DayPart.MORNING, "m",
        listOf(
            "¿Cómo te apetece empezar el día?", "¿Tienes un hueco antes de empezar con lo de hoy?",
            "¿Te apetece que el primer plan del día sea al aire libre?", "¿Qué te pide el cuerpo esta mañana?",
            "¿Hoy sales por tu cuenta o has quedado con alguien?", "¿Ya tienes el recorrido en mente?",
            "¿Buscamos una ruta cerca para esta mañana?", "¿Cuánto tiempo te apetece dedicarte hoy?",
            "¿Repites tu recorrido de siempre o pruebas otro?", "¿Echamos un vistazo a lo que toca hoy?",
            "¿Preparamos una salida corta antes del desayuno?", "¿Qué deporte eliges para arrancar la mañana?",
        ),
        listOf("¿Te apetece empezar el día con un trote suave?", "¿Dónde te gustaría dar las primeras zancadas de hoy?"),
        listOf("¿Qué sendero te gustaría recorrer esta mañana?", "¿Te apetece empezar el día por un camino entre árboles?"),
        listOf("¿Sales a pedalear antes de que empiece el día?", "¿Qué vuelta te gustaría hacer esta mañana en bici?"),
        listOf("¿Te apetece dar un paseo antes de empezar el día?", "¿Por dónde te gustaría dar los primeros pasos de la mañana?"),
    ) + block(DayPart.MIDDAY, "d",
        listOf(
            "¿Te apetece aprovechar un rato libre para salir?", "¿Qué plan te encaja antes de comer?",
            "¿Tienes media hora para ti?", "¿Qué deporte te apetece a esta hora?",
            "¿Preparamos una vuelta cerca de casa?", "¿Cómo va el día?",
            "¿Te apetece hacer una pausa y salir un rato?", "¿Has quedado para entrenar hoy?",
            "¿Cuál de tus rutas favoritas te apetece repetir?", "¿Vemos si tienes algo previsto para hoy?",
            "¿Te quedas por el barrio o buscas otra ruta?", "¿Prefieres salir ahora o dejarlo preparado para luego?",
        ),
        listOf("¿Te encaja una carrera corta al mediodía?", "¿Por dónde te apetece trotar hoy?"),
        listOf("¿Buscamos un sendero para este mediodía?", "¿Te apetece comer a la vuelta de una ruta a pie?"),
        listOf("¿Qué tal una vuelta en bici antes de comer?", "¿Tienes tiempo para sacar la bici un rato?"),
        listOf("¿Aprovechas el descanso para dar un paseo?", "¿Te apetece ir andando un poco más lejos hoy?"),
    ) + block(DayPart.AFTERNOON, "t",
        listOf(
            "¿Qué te apetece hacer esta tarde?", "¿Te queda un rato para salir?",
            "¿Hoy toca vuelta corta o tienes la tarde libre?", "¿Buscamos un recorrido para después de clase o del trabajo?",
            "¿Ya sabes por dónde vas a salir?", "¿Te apetece cambiar de ruta esta tarde?",
            "¿Con quién te gustaría entrenar hoy?", "¿Quieres ver lo que tienes en el calendario?",
            "¿Preparamos un plan para cuando acabes lo de hoy?", "¿Qué te apetece más, parque o ciudad?",
            "¿Tienes alguna salida en mente para hoy?", "¿Por dónde empezarías si salieras ahora?",
        ),
        listOf("¿Te apetece dar una vuelta corriendo esta tarde?", "¿Preparamos la carrera que tienes en mente?"),
        listOf("¿Te apetece pasar la tarde en un sendero?", "¿Buscamos un camino circular para volver al punto de salida?"),
        listOf("¿Sacamos la bici esta tarde?", "¿Hacia dónde te gustaría pedalear hoy?"),
        listOf("¿Damos un paseo para cambiar de aires?", "¿Por qué parque te apetece caminar esta tarde?"),
    ) + block(DayPart.NIGHT, "n",
        listOf(
            "¿Cómo te apetece cerrar el día?", "¿Sales un rato o preparamos lo de mañana?",
            "¿Quieres echar un vistazo a lo que has hecho hoy?", "¿Qué te apetece planear para tu próxima salida?",
            "¿Tienes un rato para ti esta noche?", "¿Vemos cómo ha ido tu semana?",
            "¿Te queda algún plan para esta noche?", "¿Quieres dejar elegida la ruta de mañana?",
            "¿Cuál ha sido tu mejor momento al aire libre hoy?", "¿Te apetece revisar tu última salida?",
            "¿Qué deporte te gustaría hacer la próxima vez?", "¿Revisamos juntos la rutina de mañana?",
        ),
        listOf("¿Preparándote para tu carrera nocturna?", "¿Qué recorrido te apetece para tu próxima carrera?"),
        listOf("¿Elegimos el sendero de tu próxima excursión?", "¿Ya sabes por qué camino saldrás mañana?"),
        listOf("¿Dejamos lista tu próxima salida en bici?", "¿Qué ruta en bici te gustaría repetir mañana?"),
        listOf("¿Te apetece un paseo para terminar el día?", "¿Por dónde te gustaría caminar mañana?"),
    )

    fun byId(id: String) = all.firstOrNull { it.id == id }
}

/** Estado de rotación de UNA franja de UN perfil: preguntas ya mostradas en el ciclo actual y última mostrada. */
@Serializable
data class GreetingCycle(val shown: List<String> = emptyList(), val last: String? = null)

object GreetingRotation {
    /**
     * Grupo de la franja: las 12 generales y, si hay deporte preferido o sesión prevista para hoy, sus 2 preguntas.
     * En una instalación nueva solo generales.
     */
    fun pool(part: DayPart, sport: Sport?, firstInstall: Boolean): List<String> =
        GreetingBank.all.filter { it.part == part && (it.sport == null || (!firstInstall && it.sport == sport)) }.map { it.id }

    /**
     * Elige la siguiente pregunta: consume el grupo en orden aleatorio, sin repeticiones, hasta agotarlo.
     * Un ciclo nuevo nunca empieza por la última pregunta del ciclo anterior. Si el grupo cambia (otro deporte),
     * las preguntas nuevas entran en el ciclo en curso.
     */
    fun next(part: DayPart, sport: Sport?, firstInstall: Boolean, state: GreetingCycle?, random: Random = Random.Default): Pair<Question, GreetingCycle> {
        val pool = pool(part, sport, firstInstall)
        val prev = state ?: GreetingCycle()
        var shown = prev.shown.filter { it in pool }
        var available = pool.filter { it !in shown }
        if (available.isEmpty()) {
            shown = emptyList()
            available = pool.filter { it != prev.last }.ifEmpty { pool }
        }
        val id = available[random.nextInt(available.size)]
        return GreetingBank.byId(id)!! to GreetingCycle(shown + id, id)
    }

    /** «{saludo}, {nombre}. {pregunta}» o, sin nombre, «{saludo}. {pregunta}». */
    fun compose(part: DayPart, name: String?, q: Question): String {
        val n = name?.trim().orEmpty()
        return if (n.isEmpty()) "${part.salute}. ${q.text}" else "${part.salute}, $n. ${q.text}"
    }
}
