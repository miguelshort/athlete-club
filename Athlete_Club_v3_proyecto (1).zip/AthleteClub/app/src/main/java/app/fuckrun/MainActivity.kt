package app.fuckrun

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.fuckrun.data.AppSettings
import app.fuckrun.data.Appearance
import app.fuckrun.data.account.AccountState
import app.fuckrun.data.account.GuestMerger
import app.fuckrun.data.db.AppDatabase
import app.fuckrun.data.db.RunStatus
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.DayPart
import app.fuckrun.domain.GreetingRotation
import app.fuckrun.domain.SessionType
import app.fuckrun.domain.Sport
import androidx.compose.runtime.saveable.rememberSaveable
import java.time.LocalDate
import java.time.LocalTime
import app.fuckrun.reminders.Reminders
import app.fuckrun.reminders.watchClubChanges
import app.fuckrun.tracking.Tracking
import app.fuckrun.ui.components.*
import app.fuckrun.ui.screens.*
import app.fuckrun.ui.theme.AthleteTheme
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val pendingIntent = MutableStateFlow<Intent?>(null)
    /** Cada vez que la persona ABRE la app desde el icono se incrementa: muestra la bienvenida. */
    private val welcomeRequests = MutableStateFlow(0)
    private var stoppedAt = 0L

    private fun fromLauncher(i: Intent?) = i?.action == Intent.ACTION_MAIN && i.hasCategory(Intent.CATEGORY_LAUNCHER) &&
        !i.getBooleanExtra("openActiveRun", false) && i.data == null

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        pendingIntent.value = intent
        // Apertura nueva desde el icono. Una rotación o volver desde la música, un permiso o Ajustes NO la repiten.
        if (savedInstanceState == null && fromLauncher(intent)) welcomeRequests.value = 1
        Reminders.rescheduleAll(applicationContext)
        val reduceMotion = runCatching { Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)
        setContent {
            val app = FuckrunApp.instance
            val graph = app.graph   // lectura observable: al cambiar de cuenta se recompone con el nuevo perfil
            val settings by remember(graph) { graph.profile.settings }.collectAsStateWithLifecycle<AppSettings?>(null)
            AthleteTheme(settings?.appearance ?: Appearance.AUTO) {
                CompositionLocalProvider(LocalReduceMotion provides reduceMotion) {
                    key(graph) { AthleteRoot(pendingIntent, settings, welcomeRequests) }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pendingIntent.value = intent
        // Tocar el icono con la app en segundo plano cuenta como apertura nueva solo tras un rato fuera (30 min):
        // así volver enseguida (p. ej. desde la música) recupera la pantalla anterior.
        if (fromLauncher(intent) && stoppedAt > 0 && System.currentTimeMillis() - stoppedAt > 30 * 60_000L) welcomeRequests.value += 1
    }

    override fun onStop() { super.onStop(); stoppedAt = System.currentTimeMillis() }
}

object Routes {
    const val HOME = "home"; const val ROUTES = "routes"; const val CLUB = "club"; const val ROUTINES = "routines"; const val PROGRESS = "progress"
    const val PROFILE = "profile"; const val ACTIVE = "active"; const val MANUAL = "manual"
    const val WELCOME = "welcome"
    fun wardrobe(tab: String = "look") = "wardrobe?tab=$tab"
    const val CLUB_CREATE = "club/create"; const val ROUTINE_NEW = "routine/new"
    fun onboarding(sport: String = "RUN") = "onboarding?sport=$sport"
    fun tutorial(replay: Boolean = false) = "tutorial?replay=$replay"
    fun account(mode: String) = "account?mode=$mode"
    fun prerun(kind: String = "FREE", planned: Long? = null, route: String? = null, shared: String? = null, sharedName: String? = null) =
        "prerun?kind=$kind&planned=${planned ?: -1}&route=${route ?: ""}&shared=${shared ?: ""}&sharedName=${android.net.Uri.encode(sharedName ?: "")}"
    fun summary(id: Long) = "summary/$id"
    fun activity(id: Long) = "activity/$id"
    fun clubSession(id: String) = "club/session/$id"
    fun clubEdit(id: String) = "club/edit/$id"
    fun clubJoin(code: String = "") = "club/join?code=$code"
}

val topLevel = listOf(
    NavItem(Routes.HOME, "Inicio", Icons.Rounded.Home),
    NavItem(Routes.ROUTES, "Rutas", Icons.Rounded.Map),
    NavItem(Routes.CLUB, "Club", Icons.Rounded.Groups),
    NavItem(Routes.ROUTINES, "Rutinas", Icons.Rounded.CalendarMonth),
    NavItem(Routes.PROGRESS, "Progreso", Icons.Rounded.Insights),
)

/** Sección (pestaña) a la que pertenece un destino, incluidos sus detalles. */
fun sectionOf(route: String?): String? = when {
    route == null -> null
    route == Routes.HOME || route.startsWith("wardrobe") || route == Routes.PROFILE || route == Routes.MANUAL -> Routes.HOME
    route == Routes.ROUTES -> Routes.ROUTES
    route == Routes.CLUB || route.startsWith("club/") -> Routes.CLUB
    route == Routes.ROUTINES || route.startsWith("routine/") -> Routes.ROUTINES
    route == Routes.PROGRESS || route.startsWith("activity/") -> Routes.PROGRESS
    else -> null
}

/**
 * Misma acción de navegación para la pestaña y para cualquier acceso de Inicio que lleve a una sección.
 *  - Inicio: vuelve a su raíz en un solo toque y conserva una única copia.
 *  - Otra sección: guarda la pila de la actual y restaura la de destino; si ya estás en esa sección (o en su detalle),
 *    vuelve a su raíz.
 */
fun NavHostController.goSection(target: String) {
    val current = currentBackStackEntry?.destination?.route
    if (target == Routes.HOME) {
        navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = false; saveState = true }; launchSingleTop = true }
        return
    }
    if (sectionOf(current) == target) { if (!popBackStack(target, inclusive = false)) navigate(target) { launchSingleTop = true }; return }
    navigate(target) { popUpTo(Routes.HOME) { saveState = true }; launchSingleTop = true; restoreState = true }
}

/** Destinos que tapan la barra inferior (registro, preparación, formularios y resumen). */
private val noBar = listOf("prerun", Routes.ACTIVE, "summary/", "account", "onboarding", "tutorial", Routes.CLUB_CREATE, "club/edit", Routes.ROUTINE_NEW, Routes.MANUAL)

@Composable
fun AthleteRoot(intents: MutableStateFlow<Intent?>, settings: AppSettings?, welcomeRequests: MutableStateFlow<Int>) {
    val ctx = LocalContext.current
    val app = FuckrunApp.instance
    val graph = FuckrunApp.graph
    val haze = remember { HazeState() }
    val sheet = remember { SheetController() }
    val nav = rememberNavController()
    val welcomeSeen by remember { app.device.welcomeSeen }.collectAsStateWithLifecycle<Boolean?>(null)
    val tutorialSeen by remember { app.device.tutorialSeen }.collectAsStateWithLifecycle<Boolean?>(null)
    val live by Tracking.live.collectAsStateWithLifecycle()
    val ended by Tracking.ended.collectAsStateWithLifecycle()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val scope = rememberCoroutineScope()
    var navHeight by remember { mutableStateOf(0.dp) }
    val density = LocalDensity.current
    val bottomInset = with(density) { WindowInsets.navigationBars.getBottom(this).toDp() }
    val requests by welcomeRequests.collectAsStateWithLifecycle()

    // Flujo de apertura (se conserva al rotar): bienvenida → [tutorial → cuenta, solo en la primera instalación] → destino.
    var flow by rememberSaveable { mutableStateOf("none") }
    var handledRequest by rememberSaveable { mutableStateOf(0) }
    var dest by rememberSaveable { mutableStateOf<String?>(null) }
    var greeting by rememberSaveable { mutableStateOf<String?>(null) }

    if (settings == null || welcomeSeen == null || tutorialSeen == null) { Box(Modifier.fillMaxSize().background(C.Bg)); return }
    val firstInstall = welcomeSeen != true

    LaunchedEffect(requests) {
        if (requests > handledRequest) { handledRequest = requests; greeting = null; dest = null; flow = "welcome" }
    }
    // La frase se elige UNA vez por apertura y se mantiene (también al abrir el desplegable).
    LaunchedEffect(flow, greeting) {
        if (flow != "welcome" || greeting != null) return@LaunchedEffect
        val part = DayPart.of(LocalTime.now().hour)
        val today = LocalDate.now().toEpochDay()
        val todaySport = graph.routines.plannedOnce().firstOrNull { it.epochDay == today && it.type != SessionType.REST.name && it.linkedRunId == null }?.sport
        val sport = todaySport?.let { Sport.of(it) } ?: settings.lastFreeSport
        val (q, cycle) = GreetingRotation.next(part, sport, firstInstall, graph.profile.greetingCycle(part))
        graph.profile.saveGreetingCycle(part, cycle)
        val name = settings.sharedDisplayName.ifBlank { (app.account.state.value as? AccountState.SignedIn)?.username.orEmpty() }
        greeting = GreetingRotation.compose(part, name, q)
    }
    fun finishFlow() {
        scope.launch { app.device.setWelcomeSeen() }
        flow = "none"
        val d = dest; dest = null
        if (d != null && d != Routes.HOME) nav.navigate(d) { launchSingleTop = true } else nav.goSection(Routes.HOME)
    }
    fun advance(from: String) {
        when (from) {
            "welcome" -> if (tutorialSeen != true) flow = "tutorial" else if (firstInstall && app.firebase.configured) flow = "account" else finishFlow()
            "tutorial" -> { scope.launch { app.device.setTutorialSeen(true) }; if (firstInstall && app.firebase.configured) flow = "account" else finishFlow() }
            else -> finishFlow()
        }
    }

    // Actividad terminada -> resumen con «Guardar actividad» y «Descartar».
    LaunchedEffect(ended) { ended?.let { flow = "none"; nav.navigate(Routes.summary(it)) { popUpTo(Routes.HOME) }; Tracking.consumeEnded() } }

    // Invitaciones (enlaces nuevos athleteclub:// y antiguos fuckrun://) y notificación de la sesión: directos a su destino.
    val pending by intents.collectAsStateWithLifecycle()
    LaunchedEffect(pending) {
        val i = pending ?: return@LaunchedEffect
        intents.value = null
        val data = i.data
        if ((data?.scheme == "athleteclub" || data?.scheme == "fuckrun") && data.host == "join") { flow = "none"; nav.navigate(Routes.clubJoin(data.lastPathSegment ?: "")) }
        if (i.getBooleanExtra("openActiveRun", false) && Tracking.live.value != null) { flow = "none"; nav.navigate(Routes.ACTIVE) { launchSingleTop = true } }
    }

    LaunchedEffect(Unit) { watchClubChanges(ctx.applicationContext) }

    // Recuperación de una actividad que no terminó correctamente (proceso cerrado, reinicio…).
    LaunchedEffect(Unit) {
        if (Tracking.live.value != null) return@LaunchedEffect
        val r = graph.runs.unfinished() ?: return@LaunchedEffect
        if (r.status == RunStatus.ENDED_UNSAVED) { flow = "none"; nav.navigate(Routes.summary(r.id)); return@LaunchedEffect }
        val last = graph.runs.points(r.id).lastOrNull()?.wallMs ?: r.startedAtWall
        val lostMin = ((System.currentTimeMillis() - last) / 60000).coerceAtLeast(0)
        sheet.dialog {
            Text("Hay una actividad sin terminar", style = T.Section)
            Spacer(Modifier.height(8.dp))
            Text("El registro se interrumpió (la app se cerró o el móvil se reinició). Último dato guardado hace $lostMin min. " +
                "Ese tramo no se ha registrado y se mostrará como hueco de señal.", style = T.Body.copy(color = C.TextSec))
            Spacer(Modifier.height(18.dp))
            if (Tracking.hasLocationPermission(ctx)) {
                PillButton("Continuar registrando", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) {
                    sheet.hide(); scope.launch { graph.runs.markInterrupted(r.id); if (Tracking.continueRun(ctx, r.id)) { flow = "none"; nav.navigate(Routes.ACTIVE) } }
                }
                Spacer(Modifier.height(10.dp))
            }
            PillButton("Terminar y revisar", color = C.Blue, icon = Icons.Rounded.Stop, modifier = Modifier.fillMaxWidth()) {
                sheet.hide(); scope.launch { graph.runs.markInterrupted(r.id); graph.runs.endRecording(r.id); flow = "none"; nav.navigate(Routes.summary(r.id)) }
            }
            Spacer(Modifier.height(10.dp))
            PillButton("Descartar", color = C.Control, textColor = C.Red, modifier = Modifier.fillMaxWidth()) {
                sheet.confirm("¿Descartar la actividad?", "Se borrarán los datos registrados de esta actividad.", "Descartar", C.Red) {
                    scope.launch { graph.runs.discard(r.id) }
                }
            }
        }
    }

    // Invitado que acaba de entrar en una cuenta: ofrecer llevar sus actividades (solo si lo confirma).
    LaunchedEffect(graph.accountUid) {
        val uid = graph.accountUid ?: return@LaunchedEffect
        if (app.device.mergeAsked(uid)) return@LaunchedEffect
        val n = withContext(Dispatchers.IO) { val gdb = AppDatabase.build(ctx.applicationContext, null); try { GuestMerger.guestCount(gdb) } finally { gdb.close() } }
        if (n == 0) { app.device.setMergeAsked(uid); return@LaunchedEffect }
        offerGuestMerge(sheet, n, uid, scope)
    }

    val section = sectionOf(route)
    val showNav = flow == "none" && section != null && noBar.none { route?.startsWith(it) == true }
    CompositionLocalProvider(LocalHaze provides haze, LocalSheet provides sheet,
        LocalNavPadding provides if (showNav) navHeight + bottomInset + 12.dp else 0.dp) {
        Box(Modifier.fillMaxSize().background(C.Bg)) {
            Box(Modifier.fillMaxSize().haze(haze)) { AppNavHost(nav) }
            if (showNav) Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp)) {
                // Acceso a la actividad en curso desde cualquier pestaña (Inicio tiene además su tarjeta).
                live?.takeIf { route != Routes.HOME }?.let { l ->
                    val paused = l.status == RunStatus.PAUSED
                    Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth().heightIn(min = 52.dp)
                        .liquid(RoundedCornerShape(50), if (paused) C.Red else C.Green, onClickLabel = "Volver a la actividad") { nav.navigate(Routes.ACTIVE) }
                        .padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (paused) Icons.Rounded.Pause else l.sport.icon, null, tint = C.OnColor)
                        Spacer(Modifier.width(8.dp))
                        Text("${if (paused) "En pausa" else "Grabando"} · ${Fmt.duration(l.stats?.activeMs)}", style = T.BodyStrong.copy(color = C.OnColor), modifier = Modifier.weight(1f))
                        Text("Volver", style = T.BodyStrong.copy(color = C.OnColor))
                    }
                }
                // La pestaña activa se calcula a partir del destino que realmente se muestra.
                FloatingNavBar(topLevel, section, onSelect = { r -> nav.goSection(r) }, modifier = rememberNavHeight { navHeight = it })
            }
            when (flow) {
                "welcome" -> greeting?.let { gText ->
                    WelcomeScreen(gText,
                        onSport = { s -> scope.launch { graph.profile.update { it.copy(lastFreeSport = s) }; dest = Routes.prerun(); advance("welcome") } },
                        onEnter = { dest = Routes.HOME; advance("welcome") },
                        onBackToActivity = { dest = Routes.ACTIVE; flow = "none"; scope.launch { app.device.setWelcomeSeen() }; nav.navigate(Routes.ACTIVE) { launchSingleTop = true } })
                } ?: Box(Modifier.fillMaxSize().background(C.Bg))
                "tutorial" -> TutorialContent { advance("tutorial") }
                "account" -> AccountIntro(
                    onCreate = { finishFlow(); nav.navigate(Routes.account("create")) },
                    onSignIn = { finishFlow(); nav.navigate(Routes.account("signin")) },
                    onContinue = { finishFlow() })
            }
            SheetHost(sheet)
        }
    }
}

fun offerGuestMerge(sheet: SheetController, n: Int, uid: String, scope: kotlinx.coroutines.CoroutineScope) {
    val app = FuckrunApp.instance
    sheet.dialog {
        var busy by remember { mutableStateOf(false) }
        Text("Tienes $n ${if (n == 1) "actividad" else "actividades"} en este móvil", style = T.Section)
        Spacer(Modifier.height(8.dp))
        Text("Las registraste sin cuenta. ¿Quieres guardarlas en esta cuenta? Solo se añaden si lo confirmas; también sus rutinas y favoritos.",
            style = T.Body.copy(color = C.TextSec))
        Spacer(Modifier.height(18.dp))
        PillButton(if (busy) "Guardando…" else "Guardar mis actividades en esta cuenta ($n)", color = C.Green, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            busy = true
            scope.launch {
                withContext(Dispatchers.IO) {
                    val gdb = AppDatabase.build(app.applicationContext, null)
                    try { GuestMerger.merge(gdb, app.graph.db) } finally { gdb.close() }
                }
                app.device.setMergeAsked(uid)
                app.sync.request()
                sheet.hide()
            }
        }
        Spacer(Modifier.height(10.dp))
        PillButton("Ahora no", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) {
            scope.launch { app.device.setMergeAsked(uid) }; sheet.hide()
        }
        Text("Si dices que no, seguirán en este móvil, en el modo sin cuenta.", style = T.Label, modifier = Modifier.padding(top = 8.dp))
    }
}

private fun optionalArg(name: String) = navArgument(name) { type = NavType.StringType; nullable = true; defaultValue = null }

@Composable
private fun AppNavHost(nav: NavHostController) {
    val reduce = LocalReduceMotion.current
    NavHost(nav, startDestination = Routes.HOME,
        enterTransition = { if (reduce) fadeIn(tween(0)) else fadeIn(tween(180)) + slideInHorizontally(tween(220)) { it / 12 } },
        exitTransition = { fadeOut(tween(if (reduce) 0 else 140)) },
        popEnterTransition = { fadeIn(tween(if (reduce) 0 else 180)) },
        popExitTransition = { if (reduce) fadeOut(tween(0)) else fadeOut(tween(140)) + slideOutHorizontally(tween(200)) { it / 12 } },
    ) {
        composable(Routes.HOME) { HomeScreen(nav) }
        composable(Routes.ROUTES) { RoutesScreen(nav) }
        composable(Routes.CLUB) { ClubScreen(nav) }
        composable(Routes.ROUTINES) { RoutinesScreen(nav) }
        composable(Routes.PROGRESS) { ProgressScreen(nav) }
        composable(Routes.PROFILE) { ProfileScreen(nav) }
        composable("wardrobe?tab={tab}", arguments = listOf(optionalArg("tab"))) { e -> WardrobeScreen(nav, e.arguments?.getString("tab") ?: "look") }
        composable("tutorial?replay={replay}", arguments = listOf(optionalArg("replay"))) { e -> TutorialScreen(nav, e.arguments?.getString("replay") == "true") }
        composable("account?mode={mode}", arguments = listOf(optionalArg("mode"))) { e -> AccountScreen(nav, e.arguments?.getString("mode") ?: "signin") }
        composable("onboarding?sport={sport}", arguments = listOf(optionalArg("sport"))) { e -> OnboardingScreen(nav, e.arguments?.getString("sport") ?: "RUN") }
        composable("prerun?kind={kind}&planned={planned}&route={route}&shared={shared}&sharedName={sharedName}",
            arguments = listOf("kind", "planned", "route", "shared", "sharedName").map { optionalArg(it) }) { e ->
            val a = e.arguments
            PreRunScreen(nav, a?.getString("kind") ?: "FREE", a?.getString("planned")?.toLongOrNull()?.takeIf { it > 0 },
                a?.getString("route")?.ifBlank { null }, a?.getString("shared")?.ifBlank { null }, a?.getString("sharedName")?.ifBlank { null })
        }
        composable(Routes.ACTIVE) { ActiveRunScreen(nav) }
        composable("summary/{id}") { e -> ActivityScreen(nav, e.arguments?.getString("id")!!.toLong(), summaryMode = true) }
        composable("activity/{id}") { e -> ActivityScreen(nav, e.arguments?.getString("id")!!.toLong(), summaryMode = false) }
        composable(Routes.MANUAL) { ManualActivityScreen(nav) }
        composable(Routes.CLUB_CREATE) { ClubEditScreen(nav, null) }
        composable("club/edit/{id}") { e -> ClubEditScreen(nav, e.arguments?.getString("id")) }
        composable("club/session/{id}") { e -> ClubSessionScreen(nav, e.arguments?.getString("id")!!) }
        composable("club/join?code={code}", arguments = listOf(optionalArg("code"))) { e -> ClubJoinScreen(nav, e.arguments?.getString("code") ?: "") }
        composable(Routes.ROUTINE_NEW) { RoutineNewScreen(nav) }
    }
}
