package app.fuckrun.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.fuckrun.FuckrunApp
import app.fuckrun.MainActivity
import app.fuckrun.R
import app.fuckrun.data.db.PlannedSessionEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/** Recordatorios opcionales de sesiones planificadas (alarmas inexactas: no requieren permisos especiales). */
object Reminders {
    fun rescheduleAll(ctx: Context) = CoroutineScope(Dispatchers.IO).launch {
        val g = FuckrunApp.graph
        val enabled = g.profile.settings.first().remindersEnabled
        val am = ctx.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()
        g.routines.plannedOnce().forEach { p ->
            val pi = pending(ctx, p)
            am.cancel(pi)
            val at = triggerAt(p) ?: return@forEach
            if (enabled && at > now && p.linkedRunId == null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun triggerAt(p: PlannedSessionEntity): Long? {
        val m = p.reminderMinuteOfDay ?: return null
        return LocalDate.ofEpochDay(p.epochDay).atTime(LocalTime.of(m / 60, m % 60)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }

    private fun pending(ctx: Context, p: PlannedSessionEntity) = PendingIntent.getBroadcast(ctx, p.id.toInt(),
        Intent(ctx, ReminderReceiver::class.java).putExtra("title", p.name).putExtra("id", p.id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        runCatching {
            nm.notify(1000 + intent.getLongExtra("id", 0).toInt(), NotificationCompat.Builder(ctx, FuckrunApp.CH_REMINDERS)
                .setSmallIcon(R.drawable.ic_stat_run).setContentTitle("Hoy toca: ${intent.getStringExtra("title")}")
                .setContentText("Puedes hacerla, reducirla o posponerla desde Rutinas.")
                .setContentIntent(open).setAutoCancel(true).build())
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        // Solo reprograma recordatorios. No inicia ningún seguimiento de ubicación.
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Reminders.rescheduleAll(ctx.applicationContext)
    }
}
