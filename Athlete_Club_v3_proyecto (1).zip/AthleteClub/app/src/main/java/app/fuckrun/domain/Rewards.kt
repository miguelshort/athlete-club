package app.fuckrun.domain

import kotlinx.serialization.Serializable

// ---------------------------------------------------------------------------------------------
// Avatar: aspecto y prendas. Todo es genérico, sin logos ni nombres comerciales.
// ---------------------------------------------------------------------------------------------

@Serializable
data class AvatarLook(
    val skin: Int = 2,          // índice en la paleta de tonos de piel
    val face: Int = 0,          // rasgos: 0 redondo, 1 ovalado, 2 marcado
    val hair: Int = 1,          // 0 rapado, 1 corto, 2 ondulado, 3 coleta, 4 moño
    val hairColor: Int = 1,     // índice en la paleta de color de pelo
)

enum class Slot(val label: String) {
    TOP("Camiseta"), BOTTOM("Parte de abajo"), SHOES("Zapatillas"),
    HEAD("Cabeza"), EYES("Gafas"), HANDS("Manos"), BACK("Espalda"), WAIST("Cintura"), NECK("Cuello"), CARRY("En la mano"),
}

@Serializable
data class Outfit(
    val top: String = "top_plain",
    val bottom: String = "bottom_straight",
    val longLegs: Boolean = false,          // false = calzonas, true = pantalón largo
    val shoes: String = "shoes_smooth",
    /** Accesorios equipados por hueco (Slot.name → id del artículo). */
    val accessories: Map<String, String> = emptyMap(),
    val topColor: Int = 0,
    val bottomColor: Int = 0,
) {
    fun with(item: ShopItem): Outfit = when (item.slot) {
        Slot.TOP -> copy(top = item.id)
        Slot.BOTTOM -> copy(bottom = item.id)
        Slot.SHOES -> copy(shoes = item.id)
        else -> copy(accessories = accessories + (item.slot.name to item.id))
    }
    fun without(slot: Slot) = copy(accessories = accessories - slot.name)
    fun isWearing(id: String) = top == id || bottom == id || shoes == id || id in accessories.values
}

/** Categorías de récord. */
enum class RecordCat(val label: String) {
    DISTANCE("Mayor distancia"), DURATION("Mayor duración activa"),
    SPEED_1K("Mayor velocidad media en 1 km"), PACE_1K("Mejor ritmo en 1 km");

    companion object {
        /** Bicicleta usa velocidad; los demás, ritmo: la misma mejora no se premia dos veces. */
        fun forSport(s: Sport) = listOf(DISTANCE, DURATION, if (s == Sport.BIKE) SPEED_1K else PACE_1K)
    }
}

sealed interface Price {
    data object Free : Price
    data class Points(val amount: Int) : Price
    /** Solo se consigue al MEJORAR un récord concreto (no con puntos). */
    data class Milestone(val sport: Sport, val cat: RecordCat) : Price
}

data class ShopItem(val id: String, val name: String, val slot: Slot, val sport: Sport?, val price: Price)

object Catalog {
    val free = listOf(
        ShopItem("top_plain", "Camiseta lisa", Slot.TOP, null, Price.Free),
        ShopItem("top_bicolor", "Camiseta bicolor", Slot.TOP, null, Price.Free),
        ShopItem("bottom_straight", "Recta", Slot.BOTTOM, null, Price.Free),
        ShopItem("bottom_stripe", "Con banda lateral", Slot.BOTTOM, null, Price.Free),
        ShopItem("shoes_smooth", "Zapatillas de suela lisa", Slot.SHOES, null, Price.Free),
        ShopItem("shoes_relief", "Zapatillas de suela con relieve", Slot.SHOES, null, Price.Free),
    )
    val shop = listOf(
        ShopItem("visor_run", "Visera de running", Slot.HEAD, Sport.RUN, Price.Points(30)),
        ShopItem("beanie_run", "Gorro térmico", Slot.HEAD, Sport.RUN, Price.Points(45)),
        ShopItem("scarf_hike", "Pañuelo de montaña", Slot.NECK, Sport.HIKE, Price.Points(25)),
        ShopItem("backpack_hike", "Mochila de senderismo", Slot.BACK, Sport.HIKE, Price.Points(60)),
        ShopItem("gloves_bike", "Guantes de ciclismo", Slot.HANDS, Sport.BIKE, Price.Points(40)),
        ShopItem("helmet_bike", "Casco", Slot.HEAD, Sport.BIKE, Price.Points(50)),
        ShopItem("cap_walk", "Gorra de paseo", Slot.HEAD, Sport.WALK, Price.Points(30)),
        ShopItem("sling_walk", "Bandolera", Slot.BACK, Sport.WALK, Price.Points(35)),
        // Exclusivos por hito: los puntos no los compran.
        ShopItem("glasses_bike", "Gafas de ciclismo", Slot.EYES, Sport.BIKE, Price.Milestone(Sport.BIKE, RecordCat.SPEED_1K)),
        ShopItem("headband_run", "Cinta de running", Slot.HEAD, Sport.RUN, Price.Milestone(Sport.RUN, RecordCat.PACE_1K)),
        ShopItem("bottle_hike", "Cantimplora de senderismo", Slot.CARRY, Sport.HIKE, Price.Milestone(Sport.HIKE, RecordCat.DISTANCE)),
        ShopItem("waistbag_walk", "Riñonera de paseo", Slot.WAIST, Sport.WALK, Price.Milestone(Sport.WALK, RecordCat.DURATION)),
    )
    val all = free + shop
    fun byId(id: String) = all.firstOrNull { it.id == id }
    fun milestoneFor(sport: Sport, cat: RecordCat) = shop.firstOrNull { (it.price as? Price.Milestone)?.let { m -> m.sport == sport && m.cat == cat } == true }
}

// ---------------------------------------------------------------------------------------------
// Récords y puntos. Lógica pura y determinista: con los mismos datos, los mismos identificadores.
// ---------------------------------------------------------------------------------------------

/** Lo que hace falta de una actividad para evaluar récords. */
data class RunFacts(
    val syncId: String,
    val sport: Sport,
    val startedAt: Long,
    val measured: Boolean,       // medida con GPS (las manuales no puntúan ni marcan récords)
    val activeMs: Long,
    val distanceM: Double?,
    /** Mejor tiempo en un tramo continuo y válido de 1 km (ms), o null si no lo hay. */
    val best1kMs: Long?,
)

data class RecordChange(val cat: RecordCat, val previous: Double?, val current: Double) {
    val isReference get() = previous == null
}

/** Movimiento de puntos con identificador estable: guardar dos veces no duplica nada. */
data class LedgerEntry(val id: String, val amount: Int, val reason: String)

data class Evaluation(
    val eligible: Boolean,
    val entries: List<LedgerEntry>,
    val changes: List<RecordChange>,
    val unlocks: List<ShopItem>,
) {
    val points get() = entries.sumOf { it.amount }
}

object Rewards {
    const val MIN_ACTIVE_MS = 5 * 60_000L
    const val POINTS_SESSION = 10
    const val POINTS_RECORD = 5

    /** Valor comparable (mayor = mejor). Ritmo: menos tiempo por km es mejor → se usa el negativo. */
    fun value(f: RunFacts, c: RecordCat): Double? = when (c) {
        RecordCat.DISTANCE -> f.distanceM?.takeIf { it > 0 }
        RecordCat.DURATION -> f.activeMs.takeIf { it > 0 }?.toDouble()
        RecordCat.SPEED_1K -> f.best1kMs?.takeIf { it > 0 }?.let { 1000.0 / (it / 1000.0) }
        RecordCat.PACE_1K -> f.best1kMs?.takeIf { it > 0 }?.let { -it.toDouble() }
    }

    fun eligible(f: RunFacts) = f.measured && f.activeMs >= MIN_ACTIVE_MS

    /**
     * Evalúa una actividad guardada frente al historial privado del MISMO deporte.
     * - 10 puntos si es una actividad medida con ≥ 5 min activos.
     * - Primera marca válida de una categoría: referencia (sin puntos extra).
     * - Mejora de una marca anterior: +5 por categoría y, si corresponde, desbloqueo del accesorio exclusivo.
     */
    fun evaluate(run: RunFacts, history: List<RunFacts>): Evaluation {
        if (!eligible(run)) return Evaluation(false, emptyList(), emptyList(), emptyList())
        val previous = history.filter { it.syncId != run.syncId && it.sport == run.sport && eligible(it) && it.startedAt < run.startedAt }
        val entries = mutableListOf(LedgerEntry("act:${run.syncId}", POINTS_SESSION, "Sesión completada"))
        val changes = mutableListOf<RecordChange>()
        val unlocks = mutableListOf<ShopItem>()
        for (c in RecordCat.forSport(run.sport)) {
            val v = value(run, c) ?: continue
            val best = previous.mapNotNull { value(it, c) }.maxOrNull()
            if (best == null) { changes += RecordChange(c, null, v); continue }
            if (v > best + 1e-6) {
                changes += RecordChange(c, best, v)
                entries += LedgerEntry("rec:${run.syncId}:${c.name}", POINTS_RECORD, "Récord: ${c.label.lowercase()}")
                Catalog.milestoneFor(run.sport, c)?.let { unlocks += it }
            }
        }
        return Evaluation(true, entries, changes, unlocks)
    }

    /** Texto de una marca para mostrar «antes → ahora». */
    fun format(c: RecordCat, v: Double): String = when (c) {
        RecordCat.DISTANCE -> "${Fmt.km(v)} km"
        RecordCat.DURATION -> Fmt.duration(v.toLong())
        RecordCat.SPEED_1K -> "${Fmt.kmh(v)} km/h"
        RecordCat.PACE_1K -> "${Fmt.pace(-v / 1000.0)} min/km"
    }

    /** Estado de un artículo en la tienda y acción correspondiente. */
    sealed interface ItemState {
        data object Equipped : ItemState
        data object Owned : ItemState
        data class Buy(val price: Int) : ItemState
        data class Missing(val price: Int, val missing: Int) : ItemState
        data class Locked(val condition: String) : ItemState
    }

    fun state(item: ShopItem, owned: Set<String>, balance: Int, outfit: Outfit, currentBest: Double?): ItemState = when {
        outfit.isWearing(item.id) -> ItemState.Equipped
        item.price is Price.Free || item.id in owned -> ItemState.Owned
        item.price is Price.Points -> { val p = (item.price as Price.Points).amount
            if (balance >= p) ItemState.Buy(p) else ItemState.Missing(p, p - balance) }
        else -> { val m = item.price as Price.Milestone
            ItemState.Locked("Mejora tu récord de ${m.sport.label}: ${m.cat.label.lowercase()}" +
                (currentBest?.let { " (tu marca: ${format(m.cat, it)})" } ?: " (aún no tienes marca)")) }
    }
}
