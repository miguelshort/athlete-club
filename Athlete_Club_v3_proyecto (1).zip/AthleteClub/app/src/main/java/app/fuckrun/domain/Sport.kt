package app.fuckrun.domain

import kotlinx.serialization.Serializable

/**
 * Deporte de una actividad. Es un dato independiente del ORIGEN de la sesión (libre, rutina, ruta o encuentro).
 * El nombre del enum es el identificador que se guarda en Room, en Firestore y en las exportaciones: no cambiarlo.
 * «Sendero» es senderismo a pie.
 */
@Serializable
enum class Sport(val label: String, val gpxType: String) {
    RUN("Correr", "running"),
    HIKE("Sendero", "hiking"),
    BIKE("Bicicleta", "cycling"),
    WALK("Caminata", "walking");

    companion object {
        /** Las carreras anteriores a la actualización no tienen deporte: se migran como Correr. */
        fun of(id: String?): Sport = entries.firstOrNull { it.name == id } ?: RUN
    }
}

/** Origen de la sesión (independiente del deporte). Coincide con los valores de RunKind. */
enum class Origin(val label: String) { FREE("Libre"), ROUTINE("Rutina"), ROUTE("Ruta"), SHARED("Encuentro del club") }

/**
 * Umbrales de filtrado por deporte (documentados en docs/METRICAS.md).
 * Sustituyen al antiguo límite global de 45 km/h, que descartaba bicicleta válida en bajadas y llanos rápidos.
 */
object SportRules {
    /** Velocidad máxima plausible entre dos fijos aceptados (m/s). */
    fun maxPlausibleMps(s: Sport): Double = when (s) {
        Sport.RUN -> 12.5      // 45 km/h: por encima no es carrera a pie
        Sport.HIKE -> 7.0      // 25 km/h: bajadas corriendo por sendero
        Sport.WALK -> 5.0      // 18 km/h
        Sport.BIKE -> 25.0     // 90 km/h: bajadas de puerto
    }

    /** Ventana de velocidad actual (ms). En bici la velocidad cambia rápido: ventana más corta. */
    fun windowMs(s: Sport): Long = if (s == Sport.BIKE) 6_000L else 10_000L
}
