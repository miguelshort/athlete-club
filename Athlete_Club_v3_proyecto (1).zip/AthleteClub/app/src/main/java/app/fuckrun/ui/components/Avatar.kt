package app.fuckrun.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import app.fuckrun.domain.AvatarLook
import app.fuckrun.domain.Outfit
import app.fuckrun.domain.Slot
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Avatar 2,5D original, dibujado en código: formas suaves, rasgos redondeados, mirada viva y luz difusa (degradados).
 * Todo el vestuario es genérico, sin logos ni marcas. Gira por vistas (frente, tres cuartos, perfil y espalda).
 */
object AvatarPalette {
    val skins = listOf(Color(0xFFFFE0C7), Color(0xFFF6CBA6), Color(0xFFE3A97F), Color(0xFFC6865C), Color(0xFF9A6240), Color(0xFF6E432A))
    val hairs = listOf(Color(0xFF1F1A17), Color(0xFF4A3426), Color(0xFF8A5A35), Color(0xFFC99A5B), Color(0xFFE6CF9F), Color(0xFFB5482E), Color(0xFF9AA0A8))
    val tops = listOf(Color(0xFF579AFF), Color(0xFFFF805F), Color(0xFF36A572), Color(0xFFF5B844), Color(0xFF2B2F38), Color(0xFFF2F3F5))
    val bottoms = listOf(Color(0xFF2B2F38), Color(0xFF3B4A6B), Color(0xFF5D6B5A), Color(0xFF8C8F96))
    val faceNames = listOf("Redondo", "Ovalado", "Marcado")
    val hairNames = listOf("Rapado", "Corto", "Ondulado", "Coleta", "Moño")
}

/** Estado de animación (respiración, peso, parpadeo, saludo, mirada, pie adelantado). */
class AvatarMotion {
    var wave by mutableFloatStateOf(0f)
    var look by mutableStateOf(Offset.Zero)     // -1..1 en cada eje
    var footForward by mutableFloatStateOf(0f)
}

@Composable
fun rememberAvatarMotion() = remember { AvatarMotion() }

/**
 * @param angle giro en grados (0 = frente, 90 = perfil, 180 = espalda).
 * @param animated respiración, parpadeo y cambio de peso; se desactiva con movimiento reducido o vista estática.
 * @param portrait solo cabeza y hombros (vista ligera para Inicio).
 */
@Composable
fun Avatar(
    look: AvatarLook,
    outfit: Outfit,
    modifier: Modifier = Modifier,
    angle: Float = 0f,
    motion: AvatarMotion = rememberAvatarMotion(),
    animated: Boolean = true,
    portrait: Boolean = false,
) {
    val reduce = LocalReduceMotion.current
    val anim = animated && !reduce
    val t = rememberInfiniteTransition(label = "avatar")
    val breath by if (anim) t.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breath") else remember { mutableFloatStateOf(0.5f) }
    val shift by if (anim) t.animateFloat(-1f, 1f, infiniteRepeatable(tween(6400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "shift") else remember { mutableFloatStateOf(0f) }
    var blink by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(anim) {
        if (!anim) { blink = 1f; return@LaunchedEffect }
        while (true) {
            delay(2200L + Random.nextLong(2600))
            blink = 0.1f; delay(110); blink = 1f
        }
    }
    Canvas(modifier.semantics { contentDescription = "Tu avatar" }) {
        drawAvatar(look, outfit, angle, breath, shift, blink, motion.wave, motion.look, motion.footForward, portrait)
    }
}

/** Avatar del vestidor: tocar → mira hacia el toque y saluda; deslizar → gira. */
@Composable
fun InteractiveAvatar(look: AvatarLook, outfit: Outfit, angle: Float, onAngle: (Float) -> Unit, motion: AvatarMotion, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val reduce = LocalReduceMotion.current
    val wave = remember { Animatable(0f) }
    LaunchedEffect(Unit) { snapshotFlow { wave.value }.collect { motion.wave = it } }
    val currentAngle by rememberUpdatedState(angle)
    val setAngle by rememberUpdatedState(onAngle)
    Avatar(look, outfit, modifier
        .pointerInput(Unit) {
            detectTapGestures { p ->
                motion.look = Offset(((p.x / size.width) - 0.5f) * 2f, ((p.y / size.height) - 0.3f) * 2f).let { Offset(it.x.coerceIn(-1f, 1f), it.y.coerceIn(-1f, 1f)) }
                if (!reduce) scope.launch {
                    wave.snapTo(0f); wave.animateTo(1f, tween(1400, easing = LinearEasing)); wave.snapTo(0f)
                    delay(600); motion.look = Offset.Zero
                } else scope.launch { delay(900); motion.look = Offset.Zero }
            }
        }
        .pointerInput(Unit) { detectHorizontalDragGestures { _, dx -> setAngle(((currentAngle + dx * 0.6f) % 360f + 360f) % 360f) } },
        angle = angle, motion = motion)
}

private fun shade(c: Color, f: Float) = Color(
    (c.red * f).coerceIn(0f, 1f), (c.green * f).coerceIn(0f, 1f), (c.blue * f).coerceIn(0f, 1f), c.alpha)

private fun DrawScope.drawAvatar(
    look: AvatarLook, outfit: Outfit, angleDeg: Float, breath: Float, shift: Float, blink: Float,
    wave: Float, lookAt: Offset, foot: Float, portrait: Boolean,
) {
    val skin = AvatarPalette.skins[look.skin.coerceIn(0, AvatarPalette.skins.lastIndex)]
    val hairC = AvatarPalette.hairs[look.hairColor.coerceIn(0, AvatarPalette.hairs.lastIndex)]
    val topC = AvatarPalette.tops[outfit.topColor.coerceIn(0, AvatarPalette.tops.lastIndex)]
    val topC2 = AvatarPalette.tops[(outfit.topColor + 4) % AvatarPalette.tops.size]
    val botC = AvatarPalette.bottoms[outfit.bottomColor.coerceIn(0, AvatarPalette.bottoms.lastIndex)]
    val a = Math.toRadians(angleDeg.toDouble())
    val facing = cos(a).toFloat()              // 1 frente, -1 espalda
    val side = sin(a).toFloat()                // + mira a su izquierda (derecha de la pantalla)
    val back = facing < -0.15f
    val wScale = 0.55f + 0.45f * abs(facing)  // de perfil el cuerpo es más estrecho

    // Unidad: el cuerpo entero mide ~10 u de alto.
    val u = if (portrait) size.height / 4.2f else size.height / 10.6f
    val cx = size.width / 2 + if (portrait) 0f else shift * u * 0.08f
    val top = if (portrait) size.height * 0.08f else size.height * 0.04f
    val breathe = 1f + breath * 0.018f

    val headR = u * 1.05f
    val headC = Offset(cx + side * u * 0.12f, top + headR + u * 0.2f + if (portrait) u * 0.3f else 0f)
    val neckTop = headC.y + headR * 0.82f
    val shoulderY = neckTop + u * 0.45f
    val torsoW = u * 2.5f * wScale * breathe
    val torsoH = u * 3.0f
    val hipY = shoulderY + torsoH
    val legH = u * 3.4f
    val ankleY = hipY + legH

    // Sombra en el suelo
    if (!portrait) drawOval(Color.Black.copy(alpha = 0.16f), Offset(cx - u * 1.7f, ankleY + u * 0.35f), Size(u * 3.4f, u * 0.5f))

    fun accessory(slot: Slot) = outfit.accessories[slot.name]

    // Mochila / bandolera detrás del cuerpo (de frente)
    fun drawBack() {
        when (accessory(Slot.BACK)) {
            "backpack_hike" -> {
                val bw = u * 2.1f * wScale; val bh = u * 2.4f
                val off = if (back) 0f else -side * u * 0.9f
                drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF3E7D5B), Color(0xFF25543B)), shoulderY, shoulderY + bh),
                    Offset(cx - bw / 2 + off, shoulderY + u * 0.15f), Size(bw, bh), CornerRadius(u * 0.5f))
                if (back) drawRoundRect(Color(0xFF2F6A4B), Offset(cx - bw * 0.35f, shoulderY + bh * 0.55f), Size(bw * 0.7f, bh * 0.35f), CornerRadius(u * 0.25f))
            }
            "sling_walk" -> drawLine(Color(0xFF8C6B4A), Offset(cx - torsoW * 0.45f, shoulderY + u * 0.1f), Offset(cx + torsoW * 0.4f, hipY - u * 0.2f), u * 0.22f, StrokeCap.Round)
        }
    }
    if (!back) drawBack()

    if (!portrait) {
        // Piernas (cambio de peso: una pierna algo flexionada; pie adelantado al probar zapatillas)
        val legW = u * 0.95f * (0.7f + 0.3f * abs(facing))
        val gap = u * 0.18f * wScale
        for (i in listOf(-1, 1)) {
            val bend = if ((i < 0) == (shift > 0)) abs(shift) * u * 0.12f else 0f
            val fwd = if (i > 0) foot * u * 0.35f else 0f
            val x = cx + i * (gap + legW / 2) * wScale - legW / 2
            val yEnd = ankleY - bend + fwd * 0.2f
            val legHeight = yEnd - hipY
            val longLegs = outfit.longLegs
            val shortsH = legHeight * 0.42f
            // Piel (pierna) y prenda inferior con volumen
            drawRoundRect(Brush.horizontalGradient(listOf(shade(skin, 0.9f), skin, shade(skin, 0.85f)), x, x + legW),
                Offset(x, hipY), Size(legW, legHeight), CornerRadius(legW / 2))
            val clothH = if (longLegs) legHeight - u * 0.15f else shortsH
            drawRoundRect(Brush.horizontalGradient(listOf(shade(botC, 0.85f), botC, shade(botC, 0.75f)), x - u * 0.06f, x + legW + u * 0.06f),
                Offset(x - u * 0.06f, hipY - u * 0.1f), Size(legW + u * 0.12f, clothH + u * 0.1f), CornerRadius(u * 0.35f))
            if (outfit.bottom == "bottom_stripe") {
                val sx = if (i < 0) x + u * 0.05f else x + legW - u * 0.05f
                drawLine(Color.White.copy(alpha = 0.9f), Offset(sx, hipY), Offset(sx, hipY + clothH - u * 0.05f), u * 0.12f, StrokeCap.Round)
            }
            // Zapatillas
            val shoeW = legW * 1.35f + abs(side) * u * 0.45f
            val sx0 = x + legW / 2 - shoeW / 2 + side * u * 0.2f
            val sy = yEnd - u * 0.15f + fwd * 0.3f
            val shoeC = if (outfit.shoes == "shoes_relief") Color(0xFFFF805F) else Color(0xFFF2F3F5)
            drawRoundRect(Brush.verticalGradient(listOf(shoeC, shade(shoeC, 0.8f)), sy, sy + u * 0.6f), Offset(sx0, sy), Size(shoeW, u * 0.6f), CornerRadius(u * 0.3f))
            drawRoundRect(Color(0xFF2B2F38), Offset(sx0, sy + u * 0.45f), Size(shoeW, u * 0.17f), CornerRadius(u * 0.08f))
            if (outfit.shoes == "shoes_relief") {
                var k = sx0 + u * 0.12f
                while (k < sx0 + shoeW - u * 0.1f) { drawLine(Color(0xFF8C8F96), Offset(k, sy + u * 0.47f), Offset(k + u * 0.08f, sy + u * 0.6f), u * 0.05f); k += u * 0.18f }
            }
        }
    }

    // Brazos (detrás del torso si se ve de lado)
    val armW = u * 0.72f * (0.75f + 0.25f * abs(facing))
    val armL = u * 2.9f
    fun drawArm(i: Int) {
        val sx = cx + i * (torsoW / 2 - armW * 0.2f)
        val waving = i > 0 && wave > 0f
        val rot = if (waving) {
            val up = (if (wave < 0.15f) wave / 0.15f else if (wave > 0.85f) (1f - wave) / 0.15f else 1f)
            -150f * up + sin(wave * 18f) * 14f * up
        } else -i * (6f + breath * 2f)   // brazos ligeramente separados del cuerpo
        // Grados en sentido horario (eje y hacia abajo): negativo separa el brazo derecho de la pantalla hacia fuera y arriba.
        rotate(rot, Offset(sx, shoulderY + armW / 2)) {
            drawRoundRect(Brush.horizontalGradient(listOf(shade(skin, 0.88f), skin, shade(skin, 0.8f)), sx - armW / 2, sx + armW / 2),
                Offset(sx - armW / 2, shoulderY), Size(armW, armL), CornerRadius(armW / 2))
            drawRoundRect(Brush.horizontalGradient(listOf(shade(topC, 0.9f), topC, shade(topC, 0.8f)), sx - armW / 2, sx + armW / 2),
                Offset(sx - armW / 2 - u * 0.04f, shoulderY), Size(armW + u * 0.08f, armL * 0.36f), CornerRadius(armW / 2))
            val handC = if (accessory(Slot.HANDS) == "gloves_bike") Color(0xFF2B2F38) else skin
            drawCircle(handC, armW * 0.62f, Offset(sx, shoulderY + armL))
            if (i < 0 && accessory(Slot.CARRY) == "bottle_hike") {
                drawRoundRect(Brush.horizontalGradient(listOf(Color(0xFF7FA7C9), Color(0xFF4E7EA6)), sx - u * 0.3f, sx + u * 0.3f),
                    Offset(sx - u * 0.28f, shoulderY + armL - u * 0.1f), Size(u * 0.56f, u * 1.1f), CornerRadius(u * 0.22f))
                drawRoundRect(Color(0xFF2B2F38), Offset(sx - u * 0.16f, shoulderY + armL - u * 0.28f), Size(u * 0.32f, u * 0.22f), CornerRadius(u * 0.06f))
            }
        }
    }
    if (abs(side) > 0.6f) drawArm(if (side > 0) -1 else 1)

    // Torso con volumen (luz desde arriba a la izquierda)
    val torsoPath = Path().apply {
        val tl = cx - torsoW / 2; val tr = cx + torsoW / 2
        moveTo(tl + u * 0.25f, shoulderY)
        lineTo(tr - u * 0.25f, shoulderY)
        quadraticTo(tr + u * 0.05f, shoulderY + u * 0.1f, tr, shoulderY + u * 0.6f)
        lineTo(tr - u * 0.2f * wScale, hipY)
        lineTo(tl + u * 0.2f * wScale, hipY)
        lineTo(tl, shoulderY + u * 0.6f)
        quadraticTo(tl - u * 0.05f, shoulderY + u * 0.1f, tl + u * 0.25f, shoulderY)
        close()
    }
    drawPath(torsoPath, Brush.linearGradient(listOf(shade(topC, 1.12f), topC, shade(topC, 0.78f)), Offset(cx - torsoW, shoulderY), Offset(cx + torsoW, hipY)))
    if (outfit.top == "top_bicolor") {
        clipPath(torsoPath) {
            drawRect(Brush.verticalGradient(listOf(topC2, shade(topC2, 0.82f)), shoulderY + torsoH * 0.55f, hipY),
                Offset(cx - torsoW, shoulderY + torsoH * 0.55f), Size(torsoW * 2, torsoH))
        }
    }
    // Cuello de la camiseta
    if (!back) drawArc(shade(topC, 0.7f), 0f, 180f, false, Offset(cx - u * 0.45f, shoulderY - u * 0.3f), Size(u * 0.9f, u * 0.6f), style = Stroke(u * 0.12f))
    if (accessory(Slot.WAIST) == "waistbag_walk") {
        drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFF5B844), Color(0xFFC98E1F)), hipY - u * 0.5f, hipY + u * 0.2f),
            Offset(cx - u * 0.75f * wScale + side * u * 0.3f, hipY - u * 0.55f), Size(u * 1.5f * wScale, u * 0.65f), CornerRadius(u * 0.3f))
        drawLine(Color(0xFF8C6B1A), Offset(cx - torsoW / 2, hipY - u * 0.3f), Offset(cx + torsoW / 2, hipY - u * 0.3f), u * 0.08f)
    }
    if (back) drawBack()

    // Brazos delante
    if (abs(side) <= 0.6f) { drawArm(-1); drawArm(1) } else drawArm(if (side > 0) 1 else -1)

    // Cuello y cabeza
    drawRoundRect(shade(skin, 0.88f), Offset(cx - u * 0.32f, neckTop - u * 0.2f), Size(u * 0.64f, u * 0.75f), CornerRadius(u * 0.3f))
    if (accessory(Slot.NECK) == "scarf_hike") {
        val p = Path().apply { moveTo(cx - u * 0.6f, neckTop + u * 0.2f); lineTo(cx + u * 0.6f, neckTop + u * 0.2f); lineTo(cx + side * u * 0.3f, neckTop + u * 1.1f); close() }
        drawPath(p, Color(0xFFD9534F))
    }
    // Pelo trasero (coleta, moño, ondulado largo)
    val hairBehind = look.hair == 2 || look.hair == 3
    if (look.hair == 3) {
        val px = headC.x - side * headR * 0.9f
        drawOval(Brush.verticalGradient(listOf(hairC, shade(hairC, 0.7f)), headC.y, headC.y + headR * 2.2f),
            Offset(px - headR * 0.35f, headC.y - headR * 0.1f), Size(headR * 0.7f, headR * 1.9f))
    }
    if (look.hair == 2) drawRoundRect(Brush.verticalGradient(listOf(hairC, shade(hairC, 0.75f))), Offset(headC.x - headR * 1.05f, headC.y - headR * 0.2f),
        Size(headR * 2.1f, headR * 1.55f), CornerRadius(headR * 0.6f))

    // Cara: forma según rasgos
    val faceW = headR * 2f * (when (look.face) { 1 -> 0.9f; 2 -> 0.95f; else -> 1f }) * (0.85f + 0.15f * abs(facing))
    val faceH = headR * 2f * (when (look.face) { 1 -> 1.1f; 2 -> 1.04f; else -> 1f })
    val faceTL = Offset(headC.x - faceW / 2, headC.y - faceH / 2)
    drawRoundRect(Brush.radialGradient(listOf(shade(skin, 1.06f), skin, shade(skin, 0.86f)), Offset(headC.x - faceW * 0.2f, headC.y - faceH * 0.25f), faceW * 0.9f),
        faceTL, Size(faceW, faceH), CornerRadius(faceW * (if (look.face == 2) 0.38f else 0.5f), faceH * 0.5f))
    // Orejas
    if (!back) for (i in listOf(-1, 1)) {
        val visible = abs(side) < 0.6f || (i > 0) == (side < 0)
        if (visible) drawOval(shade(skin, 0.9f), Offset(headC.x + i * faceW / 2 - u * 0.18f - side * u * 0.2f, headC.y - u * 0.15f), Size(u * 0.36f, u * 0.5f))
    }

    if (!back) {
        // Rasgos (desplazados con el giro y con la mirada)
        val fx = headC.x + side * faceW * 0.28f
        val eyeY = headC.y + faceH * 0.02f
        val eyeDx = faceW * 0.2f * (0.6f + 0.4f * abs(facing))
        val eyeR = u * 0.2f
        for (i in listOf(-1, 1)) {
            if (abs(side) > 0.75f && (i > 0) != (side > 0)) continue
            val ex = fx + i * eyeDx
            drawOval(Color.White, Offset(ex - eyeR, eyeY - eyeR * blink), Size(eyeR * 2, eyeR * 2 * blink))
            if (blink > 0.5f) {
                val pupil = Offset(ex + lookAt.x * eyeR * 0.45f + side * eyeR * 0.3f, eyeY + lookAt.y * eyeR * 0.35f)
                drawCircle(Color(0xFF2B2F38), eyeR * 0.62f, pupil)
                drawCircle(Color.White, eyeR * 0.2f, pupil + Offset(-eyeR * 0.2f, -eyeR * 0.22f))
            }
            drawLine(shade(hairC, 0.9f), Offset(ex - eyeR, eyeY - eyeR * 1.7f), Offset(ex + eyeR, eyeY - eyeR * 1.85f), u * 0.09f, StrokeCap.Round)
            drawCircle(Color(0xFFFF8C8C).copy(alpha = 0.28f), eyeR * 0.9f, Offset(ex + i * eyeR * 0.4f, eyeY + eyeR * 2.1f))
        }
        drawCircle(shade(skin, 0.85f), u * 0.1f, Offset(fx + side * u * 0.2f, eyeY + eyeR * 1.6f))
        drawArc(Color(0xFF8A3B32), 15f, 150f, false, Offset(fx - u * 0.32f, eyeY + eyeR * 1.9f), Size(u * 0.64f, u * 0.42f), style = Stroke(u * 0.09f, cap = StrokeCap.Round))
        if (accessory(Slot.EYES) == "glasses_bike") {
            val gy = eyeY - eyeR * 0.6f
            drawRoundRect(Brush.horizontalGradient(listOf(Color(0xFF2E3A59), Color(0xFF6C8CFF), Color(0xFF2E3A59)), fx - faceW * 0.45f, fx + faceW * 0.45f),
                Offset(fx - faceW * 0.42f, gy), Size(faceW * 0.84f, eyeR * 2.1f), CornerRadius(eyeR))
        }
    }

    // Pelo superior (por estilo)
    val hairTop = headC.y - faceH / 2
    when (look.hair) {
        0 -> drawArc(Brush.verticalGradient(listOf(hairC, shade(hairC, 0.8f))), 180f, 180f, true,
            Offset(headC.x - faceW / 2, hairTop - u * 0.02f), Size(faceW, faceH * 0.55f))
        4 -> {
            drawArc(Brush.verticalGradient(listOf(hairC, shade(hairC, 0.8f))), 180f, 180f, true, Offset(headC.x - faceW / 2 - u * 0.05f, hairTop - u * 0.05f), Size(faceW + u * 0.1f, faceH * 0.75f))
            drawCircle(Brush.radialGradient(listOf(shade(hairC, 1.15f), hairC)), headR * 0.45f, Offset(headC.x - side * headR * 0.4f, hairTop - headR * 0.25f))
        }
        else -> {
            val fringe = Path().apply {
                moveTo(headC.x - faceW / 2 - u * 0.06f, headC.y)
                cubicTo(headC.x - faceW / 2 - u * 0.1f, hairTop - u * 0.4f, headC.x + faceW / 2 + u * 0.1f, hairTop - u * 0.45f, headC.x + faceW / 2 + u * 0.06f, headC.y - u * 0.05f)
                if (!back) {
                    quadraticTo(headC.x + faceW * 0.2f + side * u * 0.3f, hairTop + faceH * 0.22f, headC.x - faceW * 0.05f, hairTop + faceH * 0.26f)
                    quadraticTo(headC.x - faceW * 0.35f, hairTop + faceH * 0.3f, headC.x - faceW / 2 - u * 0.06f, headC.y)
                } else lineTo(headC.x - faceW / 2 - u * 0.06f, headC.y + faceH * 0.3f)
                close()
            }
            drawPath(fringe, Brush.verticalGradient(listOf(shade(hairC, 1.12f), hairC, shade(hairC, 0.8f)), hairTop - u * 0.4f, headC.y + faceH * 0.3f))
            if (look.hair == 2 && !hairBehind) Unit
        }
    }
    if (back && look.hair != 0) drawRoundRect(Brush.verticalGradient(listOf(hairC, shade(hairC, 0.78f))), Offset(headC.x - faceW / 2, hairTop),
        Size(faceW, faceH * (if (look.hair == 1) 0.7f else 0.85f)), CornerRadius(faceW / 2))

    // Accesorios de cabeza
    when (accessory(Slot.HEAD)) {
        "visor_run" -> {
            drawRoundRect(Color(0xFFFF805F), Offset(headC.x - faceW / 2, hairTop + faceH * 0.12f), Size(faceW, u * 0.32f), CornerRadius(u * 0.16f))
            if (!back) drawOval(shade(Color(0xFFFF805F), 0.85f), Offset(headC.x - faceW * 0.35f + side * u * 0.6f, hairTop + faceH * 0.15f), Size(faceW * 0.85f, u * 0.4f))
        }
        "cap_walk" -> {
            drawArc(Brush.verticalGradient(listOf(Color(0xFFF5B844), Color(0xFFC98E1F))), 180f, 180f, true, Offset(headC.x - faceW / 2 - u * 0.05f, hairTop - u * 0.2f), Size(faceW + u * 0.1f, faceH * 0.7f))
            if (!back) drawOval(Color(0xFFC98E1F), Offset(headC.x - faceW * 0.3f + side * u * 0.7f, hairTop + faceH * 0.1f), Size(faceW * 0.9f, u * 0.42f))
        }
        "beanie_run" -> {
            drawArc(Brush.verticalGradient(listOf(Color(0xFF579AFF), Color(0xFF2F6FD6))), 180f, 180f, true, Offset(headC.x - faceW / 2 - u * 0.08f, hairTop - u * 0.35f), Size(faceW + u * 0.16f, faceH * 0.8f))
            drawRoundRect(Color(0xFF2F6FD6), Offset(headC.x - faceW / 2 - u * 0.1f, hairTop + faceH * 0.04f), Size(faceW + u * 0.2f, u * 0.45f), CornerRadius(u * 0.2f))
        }
        "helmet_bike" -> {
            drawArc(Brush.verticalGradient(listOf(Color(0xFFF2F3F5), Color(0xFFB9BEC7))), 180f, 180f, true, Offset(headC.x - faceW / 2 - u * 0.15f, hairTop - u * 0.4f), Size(faceW + u * 0.3f, faceH * 0.85f))
            for (k in -1..1) drawLine(Color(0xFF2B2F38), Offset(headC.x + k * faceW * 0.22f, hairTop - u * 0.25f), Offset(headC.x + k * faceW * 0.25f, hairTop + u * 0.05f), u * 0.1f, StrokeCap.Round)
        }
        "headband_run" -> drawRoundRect(Color(0xFFFF5A5F), Offset(headC.x - faceW / 2 - u * 0.04f, hairTop + faceH * 0.14f), Size(faceW + u * 0.08f, u * 0.3f), CornerRadius(u * 0.15f))
    }
    if (portrait) {
        // Recorte suave inferior para el retrato
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent), 0f, size.height))
    }
}
