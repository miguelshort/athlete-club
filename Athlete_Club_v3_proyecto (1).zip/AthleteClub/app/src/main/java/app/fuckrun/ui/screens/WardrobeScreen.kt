package app.fuckrun.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.data.AppSettings
import app.fuckrun.data.RewardsRepository
import app.fuckrun.domain.*
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch

fun slotIcon(s: Slot): ImageVector = when (s) {
    Slot.TOP -> Icons.Rounded.Checkroom; Slot.BOTTOM -> Icons.Rounded.Checkroom; Slot.SHOES -> Icons.Rounded.DirectionsRun
    Slot.HEAD -> Icons.Rounded.Face; Slot.EYES -> Icons.Rounded.Visibility; Slot.HANDS -> Icons.Rounded.BackHand
    Slot.BACK -> Icons.Rounded.Backpack; Slot.WAIST -> Icons.Rounded.ShoppingBag; Slot.NECK -> Icons.Rounded.Checkroom; Slot.CARRY -> Icons.Rounded.WaterDrop
}

/**
 * Vestidor: el avatar de cuerpo entero en el centro. Tocar una pieza la PRUEBA; «Equipar» guarda el conjunto.
 * Salir sin equipar conserva la ropa anterior. Dentro está la Tienda, que solo usa puntos ganados en la app.
 */
@Composable
fun WardrobeScreen(nav: NavController, tab0: String) {
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    val settings0 by g.profile.settings.collectAsStateWithLifecycle<AppSettings?>(null)
    val settings = settings0 ?: return
    val balance by g.rewards.balance.collectAsStateWithLifecycle(0)
    val pending by g.rewards.pendingPoints.collectAsStateWithLifecycle(0)
    val owned by g.rewards.owned.collectAsStateWithLifecycle(emptySet())
    val bests by produceState(emptyMap<Pair<Sport, RecordCat>, Double>(), owned) { value = g.rewards.bests() }
    var tab by rememberSaveable { mutableStateOf(tab0) }
    var look by remember(settings0 == null) { mutableStateOf(settings.look) }
    var outfit by remember(settings0 == null) { mutableStateOf(settings.outfit) }
    var angle by rememberSaveable { mutableStateOf(0f) }
    val motion = rememberAvatarMotion()
    val foot = remember { Animatable(0f) }
    LaunchedEffect(Unit) { snapshotFlow { foot.value }.collect { motion.footForward = it } }
    val dirty = look != settings.look || outfit != settings.outfit
    fun tryShoes() = scope.launch { foot.animateTo(1f, tween(260)); kotlinx.coroutines.delay(700); foot.animateTo(0f, tween(260)) }
    fun equip() = scope.launch { g.profile.update { it.copy(look = look, outfit = outfit) } }

    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Vestidor", style = T.ScreenTitle, modifier = Modifier.weight(1f))
            Row(Modifier.clip(RoundedCornerShape(50)).background(C.Amber.copy(alpha = 0.16f)).padding(horizontal = 12.dp, vertical = 8.dp)
                .semantics(mergeDescendants = true) { contentDescription = "Saldo: $balance puntos" }, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Stars, null, tint = C.Amber, modifier = Modifier.size(18.dp)); Text(" $balance puntos", style = T.Body)
            }
            Spacer(Modifier.width(8.dp))
            RoundIconButton(Icons.Rounded.Close, "Cerrar") { nav.popBackStack() }
        }
        if (pending > 0 && g.accountUid != null) Text("$pending puntos pendientes de copiar en tu cuenta", style = T.Label, modifier = Modifier.padding(horizontal = 20.dp))
        Box(Modifier.fillMaxWidth().height(330.dp)) {
            InteractiveAvatar(look, outfit, angle, { angle = it }, motion, Modifier.fillMaxSize())
            Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RoundIconButton(Icons.Rounded.RotateLeft, "Girar a la izquierda") { angle = (angle - 45f + 360f) % 360f }
                listOf(0f to "Frente", 90f to "Lado", 180f to "Espalda").forEach { (a, l) ->
                    Text(l, style = T.Label.copy(color = C.Text), modifier = Modifier.heightIn(min = 48.dp)
                        .liquid(RoundedCornerShape(50), if (kotlin.math.abs(angle - a) < 1f) C.Blue.copy(alpha = 0.18f) else C.Control) { angle = a }
                        .padding(horizontal = 12.dp, vertical = 14.dp))
                }
                RoundIconButton(Icons.Rounded.RotateRight, "Girar a la derecha") { angle = (angle + 45f) % 360f }
            }
        }
        // Pestañas: un grupo de opciones donde solo se deforma la pulsada.
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(26.dp)).background(C.Card).padding(4.dp)) {
            listOf("look" to "Aspecto", "clothes" to "Ropa", "acc" to "Accesorios", "shop" to "Tienda").forEach { (k, l) ->
                Box(Modifier.weight(1f).heightIn(min = 48.dp).liquid(RoundedCornerShape(22.dp), if (tab == k) C.Blue.copy(alpha = 0.18f) else Color.Transparent, role = Role.Tab) { tab = k }
                    .semantics { selected = tab == k }, contentAlignment = Alignment.Center) {
                    Text(l, style = T.Body.copy(color = if (tab == k) C.Text else C.TextSec))
                }
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (tab) {
                "look" -> {
                    Label("Tono de piel")
                    Swatches(AvatarPalette.skins, look.skin) { look = look.copy(skin = it) }
                    Label("Rasgos")
                    ChoiceChips(AvatarPalette.faceNames.indices.toList(), { AvatarPalette.faceNames[it] }, { it == look.face }) { look = look.copy(face = it) }
                    Label("Peinado")
                    ChoiceChips(AvatarPalette.hairNames.indices.toList(), { AvatarPalette.hairNames[it] }, { it == look.hair }) { look = look.copy(hair = it) }
                    Label("Color de pelo")
                    Swatches(AvatarPalette.hairs, look.hairColor) { look = look.copy(hairColor = it) }
                }
                "clothes" -> {
                    Text("Las prendas iniciales son gratuitas y se pueden combinar desde el principio.", style = T.Label)
                    Label("Camiseta")
                    ChoiceChips(listOf("top_plain", "top_bicolor"), { Catalog.byId(it)!!.name }, { it == outfit.top }) { outfit = outfit.copy(top = it) }
                    Swatches(AvatarPalette.tops, outfit.topColor) { outfit = outfit.copy(topColor = it) }
                    Label("Parte de abajo")
                    ChoiceChips(listOf("bottom_straight", "bottom_stripe"), { Catalog.byId(it)!!.name }, { it == outfit.bottom }) { outfit = outfit.copy(bottom = it) }
                    ChoiceChips(listOf(false, true), { if (it) "Pantalón largo" else "Calzonas" }, { it == outfit.longLegs }) { outfit = outfit.copy(longLegs = it) }
                    Swatches(AvatarPalette.bottoms, outfit.bottomColor) { outfit = outfit.copy(bottomColor = it) }
                    Label("Zapatillas")
                    ChoiceChips(listOf("shoes_smooth", "shoes_relief"), { Catalog.byId(it)!!.name.removePrefix("Zapatillas de ") }, { it == outfit.shoes }) {
                        outfit = outfit.copy(shoes = it); tryShoes()
                    }
                }
                "acc" -> {
                    val mine = Catalog.shop.filter { it.id in owned }
                    if (mine.isEmpty()) Text("Aún no tienes accesorios. Consíguelos en la Tienda con los puntos de tus actividades o mejorando tus récords.", style = T.Body.copy(color = C.TextSec))
                    mine.forEach { item ->
                        val wearing = outfit.isWearing(item.id)
                        ItemRow(item, if (wearing) "Puesto en la prueba" else "Conseguido", if (wearing) "Quitar" else "Probar", if (wearing) C.Control else C.Blue) {
                            outfit = if (wearing) outfit.without(item.slot) else outfit.with(item)
                        }
                    }
                }
                else -> ShopTab(owned, balance, outfit, settings.outfit, bests,
                    onTry = { item -> outfit = if (outfit.isWearing(item.id)) outfit.without(item.slot) else outfit.with(item) },
                    onEquip = { item -> outfit = outfit.with(item); scope.launch { g.profile.update { it.copy(look = look, outfit = outfit) } } },
                    onBuy = { item ->
                        val price = (item.price as Price.Points).amount
                        sheet.confirm("¿Conseguir ${item.name.lowercase()}?", "Precio: $price puntos. Te quedarán ${balance - price} puntos. Es un objeto virtual para tu avatar.",
                            "Conseguir por $price puntos", C.Green, Icons.Rounded.Stars) {
                            scope.launch {
                                when (val r = g.rewards.buy(item)) {
                                    RewardsRepository.BuyResult.Ok, RewardsRepository.BuyResult.AlreadyOwned -> outfit = outfit.with(item)
                                    is RewardsRepository.BuyResult.NotEnough -> sheet.dialog { Text("Te faltan ${r.missing} puntos", style = T.Section); Spacer(Modifier.height(12.dp))
                                        PillButton("Entendido", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { sheet.hide() } }
                                    RewardsRepository.BuyResult.NotForSale -> Unit
                                }
                            }
                        }
                    })
            }
            Spacer(Modifier.height(8.dp))
        }
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (dirty) PillButton("Deshacer prueba", color = C.Control, textColor = C.Text, modifier = Modifier.weight(1f)) { look = settings.look; outfit = settings.outfit }
            PillButton(if (dirty) "Equipar" else "Equipado", color = if (dirty) C.Green else C.Control, textColor = if (dirty) C.OnColor else C.TextSec,
                icon = Icons.Rounded.Check, enabled = dirty, modifier = Modifier.weight(1f)) { equip() }
        }
    }
}

@Composable private fun Label(t: String) = Text(t, style = T.BodyStrong, modifier = Modifier.padding(top = 4.dp))

@Composable
private fun Swatches(colors: List<Color>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEachIndexed { i, c ->
            Box(Modifier.size(48.dp).liquid(CircleShape, c, role = Role.RadioButton) { onPick(i) }
                .then(if (i == selected) Modifier.border(3.dp, C.Blue, CircleShape) else Modifier.border(1.dp, C.Border, CircleShape))
                .semantics { this.selected = i == selected; contentDescription = "Opción ${i + 1}" })
        }
    }
}

@Composable
private fun ItemRow(item: ShopItem, status: String, action: String?, actionColor: Color, onAction: () -> Unit) {
    FCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val tint = item.sport?.color ?: C.Text
            Box(Modifier.size(48.dp).clip(CircleShape).background(tint.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                Icon(slotIcon(item.slot), null, tint = tint)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, style = T.BodyStrong)
                Text(status, style = T.Label)
            }
            if (action != null) Text(action, style = T.Label.copy(color = if (actionColor == C.Control) C.Text else C.OnColor),
                modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), actionColor, onClick = onAction).padding(horizontal = 14.dp, vertical = 14.dp))
        }
    }
}

/** Tienda: saldo, categorías por deporte, vista previa en el avatar y estado/acción de cada artículo. */
@Composable
private fun ShopTab(
    owned: Set<String>, balance: Int, trial: Outfit, equipped: Outfit, bests: Map<Pair<Sport, RecordCat>, Double>,
    onTry: (ShopItem) -> Unit, onEquip: (ShopItem) -> Unit, onBuy: (ShopItem) -> Unit,
) {
    var cat by rememberSaveable { mutableStateOf(Sport.RUN.name) }
    val sport = Sport.of(cat)
    Text("Solo se gastan puntos ganados en la app: 10 por cada actividad medida de al menos 5 minutos y 5 por cada récord mejorado.", style = T.Label)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Sport.entries.forEach { s ->
            Row(Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), if (s == sport) s.color.copy(alpha = 0.18f) else C.Control, role = Role.Tab) { cat = s.name }
                .semantics { selected = s == sport }.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(s.icon, null, tint = s.color, modifier = Modifier.size(20.dp)); Text(" ${s.label}", style = T.Body)
            }
        }
    }
    Catalog.shop.filter { it.sport == sport }.forEach { item ->
        val m = item.price as? Price.Milestone
        val st = Rewards.state(item, owned, balance, equipped, m?.let { bests[it.sport to it.cat] })
        val trying = trial.isWearing(item.id) && !equipped.isWearing(item.id)
        when (st) {
            Rewards.ItemState.Equipped -> ItemRow(item, "Equipado", "Equipado", C.Control) {}
            Rewards.ItemState.Owned -> ItemRow(item, if (m != null) "Conseguido" else "Tuyo", "Equipar", C.Green) { onEquip(item) }
            is Rewards.ItemState.Buy -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ItemRow(item, "${st.price} puntos", "Conseguir por ${st.price} puntos", C.Green) { onBuy(item) }
                Text(if (trying) "Quitar prueba" else "Probar", style = T.Body.copy(color = C.Blue),
                    modifier = Modifier.padding(start = 8.dp).heightIn(min = 48.dp).liquid(RoundedCornerShape(50)) { onTry(item) }.padding(horizontal = 8.dp, vertical = 12.dp))
            }
            is Rewards.ItemState.Missing -> ItemRow(item, "${st.price} puntos", "Te faltan ${st.missing} puntos", C.Control) { onTry(item) }
            is Rewards.ItemState.Locked -> ItemRow(item, st.condition, if (trying) "Quitar prueba" else "Probar", C.Control) { onTry(item) }
        }
    }
}
