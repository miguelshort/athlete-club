package app.fuckrun.data

import androidx.room.withTransaction
import app.fuckrun.data.db.*
import app.fuckrun.domain.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

fun RunEntity.facts() = RunFacts(syncId, Sport.of(sport), startedAtWall, source == RunSource.GPS, activeMs, distanceM, best1kMs)

/**
 * Economía del club: puntos, récords, compras e inventario. Todo con identificadores estables por perfil,
 * actividad, categoría y artículo, así que repetir una operación nunca duplica abonos ni cargos.
 */
class RewardsRepository(private val db: AppDatabase) {
    private val dao = db.rewards()
    var onChange: () -> Unit = {}

    val balance: Flow<Int> = dao.balance()
    val pendingPoints: Flow<Int> = dao.pendingPoints()
    val owned: Flow<Set<String>> = dao.inventory().map { l -> l.map { it.itemId }.toSet() }
    fun entriesForRun(syncId: String) = dao.entriesForRun(syncId)

    /** Mejores marcas actuales por deporte y categoría (del historial privado). */
    suspend fun bests(): Map<Pair<Sport, RecordCat>, Double> {
        val facts = db.runs().finishedOnce().map { it.facts() }.filter { Rewards.eligible(it) }
        val out = mutableMapOf<Pair<Sport, RecordCat>, Double>()
        for (f in facts) for (c in RecordCat.forSport(f.sport)) Rewards.value(f, c)?.let { v ->
            val k = f.sport to c; if (v > (out[k] ?: Double.NEGATIVE_INFINITY)) out[k] = v
        }
        return out
    }

    /** Lo que daría guardar esta actividad (para mostrarlo en el resumen antes de guardar). */
    suspend fun preview(run: RunEntity): Evaluation =
        Rewards.evaluate(run.facts(), db.runs().finishedOnce().filter { it.id != run.id }.map { it.facts() })

    /** Concede puntos y desbloqueos de una actividad guardada. Solo se evalúa una vez por actividad. */
    suspend fun awardFor(run: RunEntity) {
        if (dao.hasEntry("act:${run.syncId}") > 0) return
        val ev = Rewards.evaluate(run.facts(), db.runs().finishedOnce().filter { it.id != run.id }.map { it.facts() })
        if (!ev.eligible) return
        db.withTransaction {
            ev.entries.forEach { dao.insertEntry(LedgerEntity(it.id, it.amount, it.reason, runSyncId = run.syncId)) }
            ev.unlocks.forEach { dao.insertItem(InventoryEntity(it.id, "MILESTONE", runSyncId = run.syncId)) }
        }
        onChange()
    }

    sealed interface BuyResult { data object Ok : BuyResult; data object AlreadyOwned : BuyResult; data class NotEnough(val missing: Int) : BuyResult; data object NotForSale : BuyResult }

    /** Compra con puntos: sin saldo negativo ni compras repetidas (transacción + identificador «buy:<artículo>»). */
    suspend fun buy(item: ShopItem): BuyResult {
        val price = (item.price as? Price.Points)?.amount ?: return BuyResult.NotForSale
        val r: BuyResult = db.withTransaction<BuyResult> {
            if (dao.inventoryOnce().any { it.itemId == item.id }) return@withTransaction BuyResult.AlreadyOwned
            val bal = dao.balanceOnce()
            if (bal < price) return@withTransaction BuyResult.NotEnough(price - bal)
            dao.insertEntry(LedgerEntity("buy:${item.id}", -price, "Compra: ${item.name}", itemId = item.id))
            dao.insertItem(InventoryEntity(item.id, "BOUGHT"))
            BuyResult.Ok
        }
        if (r == BuyResult.Ok) onChange()
        return r
    }
}
