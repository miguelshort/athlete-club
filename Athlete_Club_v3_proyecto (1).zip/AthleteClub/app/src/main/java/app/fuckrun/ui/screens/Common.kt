package app.fuckrun.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.fuckrun.FuckrunApp
import app.fuckrun.data.db.PlannedSessionEntity
import app.fuckrun.domain.SessionProposal
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.flow.first
import java.time.LocalDate

/** Tarjeta de propuesta: tipo, duración, intensidad, calentamiento, vuelta a la calma, descansos, explicación y respuestas usadas. */
@Composable
fun ProposalCard(base: SessionProposal, onStart: (SessionProposal) -> Unit, onSave: ((SessionProposal) -> Unit)? = null, onPersonalize: (() -> Unit)? = null) {
    var variant by remember(base) { mutableStateOf(0) }   // 0 original, 1 reducida, 2 caminata
    val p = when (variant) { 1 -> base.reduced(); 2 -> base.asWalk(); else -> base }
    FCard {
        Text("Sesión recomendada", style = T.Label)
        Text(p.title, style = T.Section)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            Stat("Parte principal", "${p.mainMinutes}", "min")
            Stat("Total aprox.", "${p.totalMinutes}", "min")
        }
        Spacer(Modifier.height(12.dp))
        Detail("Qué hacer", p.structure)
        Detail("Intensidad", "${p.intensity.label}: ${p.intensity.hint}")
        Detail("Calentamiento", p.warmup)
        Detail("Vuelta a la calma", p.cooldown)
        Detail("Descansos", p.restNote)
        Detail("Por qué esta sesión", p.explanation + " Respuestas usadas: " + p.usedAnswers.joinToString(" · ") + ".")
        p.cautionNote?.let { Spacer(Modifier.height(8.dp)); Notice(it, icon = Icons.Rounded.HealthAndSafety) }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            CircleAction(Icons.Rounded.Remove, if (variant == 1) "Original" else "Reducir") { variant = if (variant == 1) 0 else 1 }
            CircleAction(Icons.Rounded.DirectionsWalk, if (variant == 2) "Original" else "Caminar") { variant = if (variant == 2) 0 else 2 }
            if (onSave != null) CircleAction(Icons.Rounded.EventAvailable, "Posponer o planificar") { onSave(p) }
            if (onPersonalize != null) CircleAction(Icons.Rounded.Tune, "Ajustar") { onPersonalize() }
        }
        Spacer(Modifier.height(12.dp))
        PillButton("Preparar esta sesión", color = C.Control, textColor = C.Text, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) { onStart(p) }
        Spacer(Modifier.height(6.dp))
        Text("Orientativa. No es un programa clínico ni garantiza resultados. Si notas dolor o malestar, para.", style = T.Label)
    }
}

@Composable
fun Detail(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, style = T.Label)
        Text(value, style = T.Body)
    }
}

/** Guarda una propuesta en una rutina "Sesiones sueltas" (la crea si no existe). */
suspend fun planProposal(p: SessionProposal, day: LocalDate, sport: app.fuckrun.domain.Sport = app.fuckrun.domain.Sport.RUN) {
    val g = FuckrunApp.graph
    val existing = g.routines.routines().first().firstOrNull { it.name == "Sesiones sueltas" }
    val rid = existing?.id ?: g.routines.createManual("Sesiones sueltas", "CUSTOM", LocalDate.now(), LocalDate.now().plusYears(5))
    g.routines.add(PlannedSessionEntity(routineId = rid, name = p.title, epochDay = day.toEpochDay(), type = p.type.name,
        targetMinutes = p.mainMinutes, intensity = p.intensity.name, structure = p.structure, sport = sport.name))
}
