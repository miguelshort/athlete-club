package app.fuckrun.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.compliance
import app.fuckrun.data.sportEnum
import app.fuckrun.data.AppSettings
import app.fuckrun.data.db.RunEntity
import app.fuckrun.data.db.RunSource
import app.fuckrun.domain.*
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun ProgressScreen(nav: NavController) {
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val allRuns by remember { g.runs.finishedRuns() }.collectAsStateWithLifecycle(emptyList())
    val allPlanned by remember { g.routines.planned() }.collectAsStateWithLifecycle(emptyList())
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    var range by remember { mutableStateOf(PeriodRange.current(Period.WEEK)) }
    var calendar by remember { mutableStateOf(false) }
    var sportFilter by remember { mutableStateOf<Sport?>(null) }
    val runs = if (sportFilter == null) allRuns else allRuns.filter { it.sportEnum == sportFilter }
    val planned = if (sportFilter == null) allPlanned else allPlanned.filter { Sport.of(it.sport) == sportFilter }
    // La evolución del ritmo nunca mezcla deportes: con «Todos» se usa el último deporte elegido.
    val paceSport = sportFilter ?: settings.lastFreeSport
    val paceRuns = allRuns.filter { it.sportEnum == paceSport }

    val inRange = ProgressCalc.inRange(runs, range)
    val prev = range.previous()
    val t = ProgressCalc.totals(inRange)
    val pt = ProgressCalc.totals(ProgressCalc.inRange(runs, prev))
    val buckets = ProgressCalc.buckets(inRange, range)
    val prevBuckets = ProgressCalc.buckets(ProgressCalc.inRange(runs, prev), prev).map { it.second }
    val today = LocalDate.now()
    val comp = compliance(planned, range.start, range.end, today)
    val elapsedDays = (minOf(range.end, today).toEpochDay() - range.start.toEpochDay() + 1).coerceAtLeast(0)

    ScreenScaffold("Progreso", header = {
        Row(Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), C.Control, role = androidx.compose.ui.semantics.Role.DropdownList) {
            sheet.pick("Periodo", Period.entries, { it.label }, range.period, icon = { Icons.Rounded.DateRange }) { range = PeriodRange.current(it) }
        }.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(range.period.label, style = T.BodyStrong); Icon(Icons.Rounded.ExpandMore, null, tint = C.Text)
        }
    }) {
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SportFilterChip("Todos", null, sportFilter == null) { sportFilter = null }
                Sport.entries.forEach { s -> SportFilterChip(s.label, s, sportFilter == s) { sportFilter = s } }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(CircleShape).background(C.Control).tap { range = range.previous() }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.ChevronLeft, "Anterior", tint = C.Text) }
                Text(range.title, style = T.BodyStrong, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                Box(Modifier.size(40.dp).clip(CircleShape).background(C.Control).tap(enabled = range.end < today) { range = range.next() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.ChevronRight, "Siguiente", tint = if (range.end < today) C.Text else C.Grey) }
            }
        }
        item {
            FCard {
                Text("Kilómetros", style = T.Label)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(Fmt.km(t.distanceM, 1), style = T.HomeFigure)
                    Text(" km", style = T.Section.copy(color = C.TextSec), modifier = Modifier.padding(bottom = 6.dp))
                }
                val diff = (t.distanceM - pt.distanceM) / 1000
                Text("${if (diff >= 0) "+" else ""}${"%.1f".format(ES, diff)} km respecto al periodo anterior", style = T.Label)
                Spacer(Modifier.height(16.dp))
                BarChart(buckets, prevBuckets.takeIf { it.size == buckets.size }, "km")
            }
        }
        item {
            FCard {
                Row(Modifier.padding(bottom = 10.dp)) {
                    Stat("Tiempo activo", Fmt.durationShort(t.activeMs), modifier = Modifier.weight(1f))
                    Stat("Sesiones", "${t.sessions}", modifier = Modifier.weight(1f))
                }
                Row {
                    Stat("Duración media", t.avgDurationMs?.let { Fmt.durationShort(it) } ?: NO_DATA, modifier = Modifier.weight(1f))
                    Stat("Ritmo medio", Fmt.pace(t.aggregatedPaceSecPerKm), "min/km", modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Text("${t.measured} medidas con GPS · ${t.manual} introducidas a mano. El ritmo medio se calcula con el tiempo y la distancia acumulados (ponderado por distancia)." +
                    if (sportFilter == null) " Mezcla deportes: filtra por uno para comparar ritmos." else "", style = T.Label)
            }
        }
        item { SectionTitle("Evolución del ritmo · ${paceSport.label}") }
        item {
            FCard {
                PaceLine(ProgressCalc.paceSeries(ProgressCalc.inRange(paceRuns, range), range), buckets.map { it.first })
                Spacer(Modifier.height(8.dp))
                Notice("Un ritmo más rápido no significa necesariamente una mejora: la distancia, el terreno, el clima y el tipo de sesión cambian de un día a otro.")
            }
        }
        item { SectionTitle("Cumplimiento de rutinas") }
        item {
            FCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ComplianceDonut(comp.done, comp.missed, comp.pending)
                    Spacer(Modifier.width(18.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        LegendRow(C.Green, "${comp.done} completadas")
                        LegendRow(C.Red, "${comp.missed} vencidas sin completar")
                        LegendRow(C.Grey, "${comp.pending} pendientes o futuras")
                        Text("${comp.rest} días de descanso (no cuentan)", style = T.Label)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Sesiones planificadas entre ${Fmt.date(range.start)} y ${Fmt.date(range.end)}.", style = T.Label)
            }
        }
        item { SectionTitle("Actividad y descanso") }
        item {
            FCard {
                Row {
                    Stat("Días con actividad", "${t.activeDays.size}", modifier = Modifier.weight(1f))
                    Stat("Días sin actividad", "${(elapsedDays - t.activeDays.size).coerceAtLeast(0)}", modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Text("Por día de la semana", style = T.Label)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    DayOfWeek.values().forEach { dow ->
                        val n = t.activeDays.count { it.dayOfWeek == dow }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(32.dp).clip(CircleShape).background(if (n > 0) C.Chart.copy(alpha = (0.35f + 0.15f * n).coerceAtMost(1f)) else C.Control), contentAlignment = Alignment.Center) {
                                Text("$n", style = T.Label.copy(color = if (n > 0) C.OnColor else C.TextSec))
                            }
                            Text(Fmt.dayShort(dow).take(1), style = T.Label)
                        }
                    }
                }
            }
        }
        item {
            SectionTitle("Historial", if (calendar) "Ver lista" else "Ver calendario") { calendar = !calendar }
        }
        if (calendar) item { HistoryCalendar(runs, YearMonth.from(range.start)) { nav.navigate(Routes.activity(it.id)) } }
        else {
            if (inRange.isEmpty()) item { Text("Sin actividades en este periodo.", style = T.Label, modifier = Modifier.padding(4.dp)) }
            items(inRange.size) { i -> RunRow(inRange[i]) { nav.navigate(Routes.activity(inRange[i].id)) } }
        }
        item { PillButton("Añadir actividad manual", color = C.Control, textColor = C.Text, icon = Icons.Rounded.EditNote, modifier = Modifier.fillMaxWidth()) { nav.navigate(Routes.MANUAL) } }
    }
}

@Composable
private fun LegendRow(color: androidx.compose.ui.graphics.Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) { LegendDot(color); Text("  $text", style = T.Body) }
}

@Composable
private fun SportFilterChip(label: String, sport: Sport?, selected: Boolean, onClick: () -> Unit) {
    val color = sport?.color ?: C.Text
    Row(Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), if (selected) color.copy(alpha = 0.18f) else C.Control, role = androidx.compose.ui.semantics.Role.Tab, onClick = onClick)
        .padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (sport != null) { Icon(sport.icon, null, tint = sport.color, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(6.dp)) }
        Text(label, style = T.Body.copy(color = C.Text))
        if (selected) { Spacer(Modifier.width(4.dp)); Icon(Icons.Rounded.Check, "Seleccionado", tint = color, modifier = Modifier.size(18.dp)) }
    }
}

@Composable
fun RunRow(r: RunEntity, onClick: () -> Unit) {
    val d = ProgressCalc.dateOf(r)
    val sport = r.sportEnum
    FCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SportBadge(sport, 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(Fmt.dateLong(d), style = T.BodyStrong)
                Text(listOf(sport.label, Fmt.durationShort(r.activeMs), if (r.source == RunSource.MANUAL) "manual" else null).filterNotNull().joinToString(" · "), style = T.Label)
            }
            Text("${Fmt.km(r.distanceM)} km", style = T.SmallNumber)
        }
    }
}

@Composable
private fun HistoryCalendar(runs: List<RunEntity>, initial: YearMonth, onOpen: (RunEntity) -> Unit) {
    var month by remember(initial) { mutableStateOf(initial) }
    val sheet = LocalSheet.current
    val byDay = runs.groupBy { ProgressCalc.dateOf(it) }
    FCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.ChevronLeft, "Mes anterior", tint = C.Text, modifier = Modifier.clip(CircleShape).tap { month = month.minusMonths(1) }.padding(6.dp))
            Text(Fmt.month(month), style = T.BodyStrong, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            Icon(Icons.Rounded.ChevronRight, "Mes siguiente", tint = C.Text, modifier = Modifier.clip(CircleShape).tap { month = month.plusMonths(1) }.padding(6.dp))
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) { DayOfWeek.values().forEach { Text(Fmt.dayShort(it).take(1), style = T.Label, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) } }
        val first = month.atDay(1)
        val offset = first.dayOfWeek.value - 1
        val cells = offset + month.lengthOfMonth()
        (0 until (cells + 6) / 7).forEach { w ->
            Row(Modifier.fillMaxWidth()) {
                (0..6).forEach { c ->
                    val idx = w * 7 + c - offset
                    Box(Modifier.weight(1f).aspectRatio(1f).padding(3.dp), contentAlignment = Alignment.Center) {
                        if (idx in 0 until month.lengthOfMonth()) {
                            val day = first.plusDays(idx.toLong())
                            val list = byDay[day].orEmpty()
                            Box(Modifier.fillMaxSize().clip(CircleShape).background(if (list.isNotEmpty()) C.Chart else androidx.compose.ui.graphics.Color.Transparent)
                                .tap(enabled = list.isNotEmpty()) {
                                    if (list.size == 1) onOpen(list.first())
                                    else sheet.pick(Fmt.dateLong(day), list, { "${it.sportEnum.label} · ${Fmt.km(it.distanceM)} km · ${Fmt.durationShort(it.activeMs)}" }, null,
                                        icon = { it.sportEnum.icon }, tint = { it.sportEnum.color }) { onOpen(it) }
                                }, contentAlignment = Alignment.Center) {
                                Text("${idx + 1}", style = T.Label.copy(color = if (list.isNotEmpty()) C.OnColor else C.Text))
                            }
                        }
                    }
                }
            }
        }
    }
}
