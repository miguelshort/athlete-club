package app.fuckrun.data.account

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import app.fuckrun.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseOptions
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

/**
 * Inicialización única de Firebase a partir de local.properties. Sin claves, todo queda «no configurado»
 * y la app funciona en local (registro, historial, estadísticas y rutinas).
 */
class FirebaseHolder(private val ctx: Context) {
    val app: FirebaseApp? = runCatching {
        if (BuildConfig.FIREBASE_API_KEY.isBlank() || BuildConfig.FIREBASE_APP_ID.isBlank() || BuildConfig.FIREBASE_PROJECT_ID.isBlank()) null
        else FirebaseApp.getApps(ctx).firstOrNull() ?: FirebaseApp.initializeApp(ctx, FirebaseOptions.Builder()
            .setApiKey(BuildConfig.FIREBASE_API_KEY).setApplicationId(BuildConfig.FIREBASE_APP_ID)
            .setProjectId(BuildConfig.FIREBASE_PROJECT_ID).build())
    }.getOrNull()

    val auth: FirebaseAuth? = app?.let { runCatching { FirebaseAuth.getInstance(it) }.getOrNull() }

    /**
     * Caché solo en memoria: ninguna escritura queda «pendiente» aparentando que se ha enviado.
     * Room es la copia local; el servidor solo cuenta como copia cuando confirma.
     */
    val fs: FirebaseFirestore? = app?.let { a ->
        runCatching {
            FirebaseFirestore.getInstance(a).also {
                it.firestoreSettings = FirebaseFirestoreSettings.Builder()
                    .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build()).build()
            }
        }.getOrNull()
    }

    val configured get() = app != null && auth != null

    fun online(): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.activeNetwork?.let { cm.getNetworkCapabilities(it)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) } == true
    }
}

sealed interface AccountState {
    /** Falta la configuración de Firebase en esta compilación. */
    data object NotConfigured : AccountState
    /** Sin cuenta: todo vive en este móvil. */
    data object Guest : AccountState
    /** Perfil anónimo creado para Club (versiones anteriores). Para el historial cuenta como invitado. */
    data class ClubOnly(val uid: String) : AccountState
    data class SignedIn(val uid: String, val email: String, val username: String, val verified: Boolean) : AccountState
}

val AccountState.accountUid: String? get() = (this as? AccountState.SignedIn)?.uid

class AccountError(msg: String) : Exception(msg)

/**
 * Cuenta con correo y contraseña (Firebase Authentication). La contraseña la gestiona el servicio de autenticación:
 * la app nunca la guarda ni la registra.
 */
class AccountRepository(private val fb: FirebaseHolder) {
    private val _state = MutableStateFlow(compute())
    val state: StateFlow<AccountState> = _state.asStateFlow()

    init {
        fb.auth?.addAuthStateListener { _state.value = compute() }
    }

    private fun compute(): AccountState {
        val a = fb.auth ?: return AccountState.NotConfigured
        val u = a.currentUser ?: return AccountState.Guest
        if (u.isAnonymous) return AccountState.ClubOnly(u.uid)
        return AccountState.SignedIn(u.uid, u.email ?: "", u.displayName ?: "", u.isEmailVerified)
    }

    /** uid del perfil local que debe usarse al arrancar (antes de que llegue ningún evento). */
    fun currentAccountUid(): String? = compute().accountUid

    private fun requireAuth() = fb.auth ?: throw AccountError("La cuenta no está configurada en esta versión. Puedes seguir sin cuenta.")

    private suspend fun <T> call(block: suspend () -> T): T = try {
        if (!fb.online()) throw AccountError("Sin conexión. Conéctate a Internet e inténtalo de nuevo.")
        withTimeout(20_000) { block() }
    } catch (e: AccountError) { throw e }
    catch (e: kotlinx.coroutines.TimeoutCancellationException) { throw AccountError("El servidor no responde. Inténtalo de nuevo.") }
    catch (e: kotlinx.coroutines.CancellationException) { throw e }
    catch (e: Exception) { throw AccountError(message(e)) }

    private fun message(e: Exception): String = when (e) {
        is FirebaseAuthWeakPasswordException -> "La contraseña es demasiado débil. Usa al menos 8 caracteres."
        is FirebaseAuthUserCollisionException -> "Ya existe una cuenta con ese correo. Prueba a iniciar sesión."
        is FirebaseAuthInvalidUserException -> "No hay ninguna cuenta con ese correo, o está desactivada."
        is FirebaseAuthInvalidCredentialsException -> "El correo o la contraseña no son correctos."
        is FirebaseAuthRecentLoginRequiredException -> "Por seguridad, cierra sesión, vuelve a entrar y repite la acción."
        is FirebaseNetworkException -> "Sin conexión. Inténtalo de nuevo."
        is FirebaseTooManyRequestsException -> "Demasiados intentos. Espera unos minutos."
        else -> "No se ha podido completar. Inténtalo de nuevo."
    }

    /**
     * Crea la cuenta. Si ya existía un perfil anónimo de Club, se VINCULA (conserva el mismo uid) para no perder
     * invitaciones ni encuentros. Envía el correo de verificación.
     */
    suspend fun create(email: String, password: String, username: String) = call {
        val auth = requireAuth()
        val cred = EmailAuthProvider.getCredential(email.trim(), password)
        val cur = auth.currentUser
        val user = if (cur != null && cur.isAnonymous) cur.linkWithCredential(cred).await().user
            else auth.createUserWithEmailAndPassword(email.trim(), password).await().user
        user ?: throw AccountError("No se ha podido crear la cuenta.")
        user.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(username.trim()).build()).await()
        runCatching { user.sendEmailVerification().await() }
        user.reload().await()
        // Token nuevo con el correo: las reglas de private/{uid} lo exigen (un perfil anónimo vinculado lo obtiene aquí).
        runCatching { user.getIdToken(true).await() }
        _state.value = compute()
    }

    suspend fun signIn(email: String, password: String) = call {
        requireAuth().signInWithEmailAndPassword(email.trim(), password).await()
        _state.value = compute()
    }

    suspend fun resetPassword(email: String) = call { requireAuth().sendPasswordResetEmail(email.trim()).await() }

    suspend fun resendVerification() = call { requireAuth().currentUser?.sendEmailVerification()?.await() }

    /** Vuelve a leer el estado de verificación desde el servidor. */
    suspend fun refresh() = call { requireAuth().currentUser?.reload()?.await(); _state.value = compute() }

    fun signOut() { fb.auth?.signOut(); _state.value = compute() }

    /** Borra el usuario de autenticación (los datos privados se borran antes desde Sync). */
    suspend fun deleteUser() = call { requireAuth().currentUser?.delete()?.await(); _state.value = compute() }
}
