package app.fuckrun.domain

import app.fuckrun.domain.metrics.RunMetrics
import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.ln

/** Datos mínimos de un recorrido candidato para seleccionar cinco distintos. */
data class RouteCandidate(
    val id: String,
    val name: String,
    val distanceM: Double,
    val surface: String?,
    val ascentM: Double?,
    val startLat: Double,
    val startLon: Double,
    val endLat: Double,
    val endLon: Double,
)

/**
 * Selección de «Rutas en {municipio}»:
 *  1. Antes de llegar aquí ya se han filtrado los recorridos APTOS para el deporte.
 *  2. Se eliminan variantes del mismo trazado: mismo nombre normalizado, o salida y llegada a menos de 200 m con
 *     longitud parecida (±12 %). Se conserva la de identificador menor (estable).
 *  3. Se eligen hasta 5 maximizando la variedad: distancia (escala logarítmica), superficie, desnivel y punto de salida.
 * Determinista: con la misma entrada devuelve siempre las mismas cinco, en el mismo orden.
 */
object RouteSelect {
    const val TARGET = 5

    fun norm(s: String) = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}"), "").lowercase()
        .replace(Regex("\\b(variante|tramo|etapa|ida|vuelta|alternativa|circular)\\b"), "").replace(Regex("[^a-z0-9]+"), " ").trim()

    fun isVariant(a: RouteCandidate, b: RouteCandidate): Boolean {
        if (a.name.isNotBlank() && norm(a.name) == norm(b.name) && norm(a.name).isNotEmpty()) return true
        val starts = RunMetrics.haversine(a.startLat, a.startLon, b.startLat, b.startLon) < 200 &&
            RunMetrics.haversine(a.endLat, a.endLon, b.endLat, b.endLon) < 200
        val reversed = RunMetrics.haversine(a.startLat, a.startLon, b.endLat, b.endLon) < 200 &&
            RunMetrics.haversine(a.endLat, a.endLon, b.startLat, b.startLon) < 200
        val similarLength = abs(a.distanceM - b.distanceM) <= 0.12 * maxOf(a.distanceM, b.distanceM)
        return (starts || reversed) && similarLength
    }

    fun dedupe(list: List<RouteCandidate>): List<RouteCandidate> {
        val out = mutableListOf<RouteCandidate>()
        for (c in list.sortedBy { it.id }) if (out.none { isVariant(it, c) }) out += c
        return out
    }

    private fun diff(a: RouteCandidate, b: RouteCandidate): Double {
        var d = abs(ln(a.distanceM.coerceAtLeast(100.0)) - ln(b.distanceM.coerceAtLeast(100.0)))
        if (a.surface != null && b.surface != null && a.surface != b.surface) d += 0.4
        if (a.ascentM != null && b.ascentM != null && abs(a.ascentM - b.ascentM) > 50) d += 0.3
        if (RunMetrics.haversine(a.startLat, a.startLon, b.startLat, b.startLon) > 1000) d += 0.3
        return d
    }

    fun pick(candidates: List<RouteCandidate>, n: Int = TARGET): List<RouteCandidate> {
        val pool = dedupe(candidates).filter { it.distanceM >= 300 }
        if (pool.size <= n) return pool.sortedBy { it.distanceM }
        // Empieza por la de longitud más cercana a la mediana y añade siempre la más distinta de las ya elegidas.
        val median = pool.map { it.distanceM }.sorted()[pool.size / 2]
        val chosen = mutableListOf(pool.minWith(compareBy<RouteCandidate>({ abs(it.distanceM - median) }, { it.id })))
        while (chosen.size < n) {
            val next = pool.filter { it !in chosen }
                .maxWith(compareBy<RouteCandidate>({ c -> chosen.minOf { diff(it, c) } }).thenByDescending { it.id })
            chosen += next
        }
        return chosen.sortedBy { it.distanceM }
    }
}
